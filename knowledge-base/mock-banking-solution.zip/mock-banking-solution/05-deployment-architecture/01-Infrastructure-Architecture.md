# Infrastructure Architecture - Customer Lifecycle Management

## 1. Infrastructure Overview

The Customer Lifecycle Management system is deployed on a cloud-native infrastructure using Kubernetes for container orchestration, providing high availability, scalability, and security for banking workloads.

## 2. Cloud Architecture

### 2.1 Multi-Region Deployment

```
Primary Region (us-east-1)
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Internet Gateway                                   │
└─────────────────────────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Application Load Balancer                            │
└─────────────────────────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              Web Tier                                         │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │
│  │   Web       │ │   Mobile    │ │   Staff     │ │   Admin     │ │   API       │ │
│  │   Frontend  │ │   Backend   │ │   Portal    │ │   Console   │ │   Gateway   │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Application Tier                                   │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │
│  │ Customer    │ │   Account   │ │ Transaction │ │ Compliance │ │   CRM       │ │
│  │   Service   │ │   Service   │ │   Service   │ │   Service   │ │   Service   │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              Data Tier                                         │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │
│  │ PostgreSQL  │ │   MongoDB   │ │    Redis    │ │Elasticsearch│ │  Object     │ │
│  │   Cluster   │ │   Cluster   │ │   Cluster   │ │   Cluster   │ │  Storage    │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Management Layer                                   │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │
│  │   Logging   │ │   Monitor   │ │   Backup    │ │   Security  │ │   CI/CD     │ │
│  │   Systems   │ │   Systems   │ │   Systems   │ │   Tools     │ │   Pipeline  │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Disaster Recovery Region

```
Secondary Region (us-west-2)
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Standby Infrastructure                             │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │
│  │   Load      │ │   Service   │ │   Database  │ │   Storage   │ │   Backup    │ │
│  │ Balancer    │ │   Cluster   │ │   Cluster   │ │   Cluster   │ │   Storage   │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Data Synchronization                               │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │
│  │   Database  │ │   Object    │ │   File      │ │   Config    │ │   Cache     │ │
│  │ Replication│ │   Sync      │ │   Sync      │ │   Sync      │ │   Sync      │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## 3. Container Architecture

### 3.1 Kubernetes Cluster Design

#### Cluster Configuration
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: cluster-config
  namespace: kube-system
data:
  cluster.name: "clm-prod"
  cluster.region: "us-east-1"
  cluster.environment: "production"
  cluster.version: "1.24"
  network.cni: "calico"
  network.pod_cidr: "10.244.0.0/16"
  network.service_cidr: "10.96.0.0/12"
  storage.class: "gp3-encrypted"
  security.pod_security_policy: "restricted"
  monitoring.enabled: "true"
  logging.enabled: "true"
```

#### Node Pool Configuration
```yaml
apiVersion: v1
kind: NodePool
metadata:
  name: application-nodes
spec:
  replicas: 6
  instance_type: "m5.xlarge"
  disk_size: "100Gi"
  disk_type: "gp3"
  labels:
    node-type: "application"
    workload: "stateless"
  taints:
    - key: "workload"
      value: "stateless"
      effect: "NoSchedule"
  auto_scaling:
    min_replicas: 3
    max_replicas: 12
    target_cpu_utilization: 70
    target_memory_utilization: 80
---
apiVersion: v1
kind: NodePool
metadata:
  name: database-nodes
spec:
  replicas: 3
  instance_type: "r5.2xlarge"
  disk_size: "500Gi"
  disk_type: "io2"
  labels:
    node-type: "database"
    workload: "stateful"
  taints:
    - key: "workload"
      value: "stateful"
      effect: "NoSchedule"
  auto_scaling:
    min_replicas: 3
    max_replicas: 6
    target_cpu_utilization: 60
    target_memory_utilization: 70
```

### 3.2 Service Deployment

#### Microservice Deployment Example
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: customer-service
  namespace: clm-system
  labels:
    app: customer-service
    version: v1.0.0
spec:
  replicas: 3
  selector:
    matchLabels:
      app: customer-service
  template:
    metadata:
      labels:
        app: customer-service
        version: v1.0.0
    spec:
      containers:
      - name: customer-service
        image: clm/customer-service:1.0.0
        ports:
        - containerPort: 8080
          name: http
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: database-credentials
              key: url
        - name: REDIS_URL
          valueFrom:
            configMapKeyRef:
              name: service-config
              key: redis-url
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
        securityContext:
          runAsNonRoot: true
          runAsUser: 1000
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop:
            - ALL
      securityContext:
        fsGroup: 2000
---
apiVersion: v1
kind: Service
metadata:
  name: customer-service
  namespace: clm-system
  labels:
    app: customer-service
spec:
  selector:
    app: customer-service
  ports:
  - port: 80
    targetPort: 8080
    name: http
  type: ClusterIP
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: customer-service-ingress
  namespace: clm-system
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
spec:
  tls:
  - hosts:
    - api.clm-banking.com
    secretName: customer-service-tls
  rules:
  - host: api.clm-banking.com
    http:
      paths:
      - path: /api/v1/customers
        pathType: Prefix
        backend:
          service:
            name: customer-service
            port:
              number: 80
```

## 4. Database Infrastructure

### 4.1 PostgreSQL Cluster

#### Primary-Replica Configuration
```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: postgres-cluster
  namespace: clm-database
spec:
  instances: 3
  primaryUpdateStrategy: unsupervised
  
  postgresql:
    parameters:
      max_connections: "200"
      shared_buffers: "256MB"
      effective_cache_size: "1GB"
      work_mem: "4MB"
      maintenance_work_mem: "64MB"
      checkpoint_completion_target: "0.9"
      wal_buffers: "16MB"
      default_statistics_target: "100"
      random_page_cost: "1.1"
      effective_io_concurrency: "200"
      work_mem: "4MB"
      min_wal_size: "1GB"
      max_wal_size: "4GB"
      
  bootstrap:
    initdb:
      database: clm
      owner: clm_user
      secret:
        name: postgres-credentials
        
  storage:
    size: 100Gi
    storageClass: gp3-encrypted
    walStorage:
      size: 10Gi
      storageClass: gp3-encrypted
      
  monitoring:
    enabled: true
    
  backup:
    retentionPolicy: "30d"
    barmanObjectStore:
      destinationPath: "s3://clm-backups/postgres"
      s3Credentials:
        accessKeyId:
          name: backup-credentials
          key: ACCESS_KEY_ID
        secretAccessKey:
          name: backup-credentials
          key: SECRET_ACCESS_KEY
      wal:
        compression: gzip
        encryption: AES256
      data:
        compression: gzip
        encryption: AES256
        jobs: 2
---
apiVersion: postgresql.cnpg.io/v1
kind: ScheduledBackup
metadata:
  name: postgres-daily-backup
  namespace: clm-database
spec:
  schedule: "0 2 * * *"
  backupOwnerName: "backup"
  cluster:
    name: postgres-cluster
```

### 4.2 MongoDB Cluster

#### Replica Set Configuration
```yaml
apiVersion: mongodbcommunity.mongodb.com/v1
kind: MongoDBCommunity
metadata:
  name: mongodb-cluster
  namespace: clm-database
spec:
  members: 3
  type: ReplicaSet
  version: "6.0"
  security:
    authentication:
      modes: ["SCRAM"]
    tls:
      enabled: true
      certificateKeyRef:
        name: mongodb-tls
        key: tls.key
      caKeyRef:
        name: mongodb-tls
        key: ca.crt
  statefulSet:
    spec:
      template:
        spec:
          containers:
          - name: mongod
            resources:
              requests:
                memory: "2Gi"
                cpu: "1000m"
              limits:
                memory: "4Gi"
                cpu: "2000m"
            volumeMounts:
            - name: data-volume
              mountPath: /data/db
            - name: config-volume
              mountPath: /data/configdb
            - name: logs-volume
              mountPath: /data/logs
  volumeClaimTemplates:
  - metadata:
      name: data-volume
    spec:
      accessModes: ["ReadWriteOnce"]
      storageClassName: gp3-encrypted
      resources:
        requests:
          storage: 100Gi
  - metadata:
      name: config-volume
    spec:
      accessModes: ["ReadWriteOnce"]
      storageClassName: gp3-encrypted
      resources:
        requests:
          storage: 10Gi
  - metadata:
      name: logs-volume
    spec:
      accessModes: ["ReadWriteOnce"]
      storageClassName: gp3-encrypted
      resources:
        requests:
          storage: 20Gi
```

### 4.3 Redis Cluster

#### Cluster Configuration
```yaml
apiVersion: redis.redis.opstreelabs.in/v1beta1
kind: RedisCluster
metadata:
  name: redis-cluster
  namespace: clm-cache
spec:
  clusterSize: 6
  clusterVersion: v7.0.5
  persistenceEnabled: true
  
  redisExporter:
    enabled: true
    image: oliver006/redis_exporter:latest
    
  storage:
    volumeClaimTemplate:
      spec:
        accessModes: ["ReadWriteOnce"]
        resources:
          requests:
            storage: 20Gi
        storageClassName: gp3-encrypted
        
  resources:
    requests:
      memory: "1Gi"
      cpu: "500m"
    limits:
      memory: "2Gi"
      cpu: "1000m"
      
  securityContext:
    runAsUser: 999
    runAsGroup: 999
    fsGroup: 999
    
  tls:
    ca: ca.crt
    cert: tls.crt
    key: tls.key
```

## 5. Storage Architecture

### 5.1 Object Storage

#### S3 Bucket Configuration
```yaml
apiVersion: s3.aws.crossplane.io/v1alpha1
kind: Bucket
metadata:
  name: clm-artefacts
  namespace: clm-storage
spec:
  forProvider:
    region: us-east-1
    acl: private
    versioningConfiguration:
      status: Enabled
    serverSideEncryptionConfiguration:
      rules:
      - applyServerSideEncryptionByDefault:
          sseAlgorithm: AES256
    publicAccessBlockConfiguration:
      blockPublicAcls: true
      blockPublicPolicy: true
      ignorePublicAcls: true
      restrictPublicBuckets: true
    lifecycleConfiguration:
      rules:
      - id: "DeleteOldVersions"
        status: Enabled
        expiration:
          days: 365
        noncurrentVersionExpiration:
          noncurrentDays: 30
      - id: "TransitionToIA"
        status: Enabled
        transitions:
        - days: 30
          storageClass: STANDARD_IA
        - days: 90
          storageClass: GLACIER
        - days: 365
          storageClass: DEEP_ARCHIVE
```

### 5.2 Backup Storage

#### Backup Strategy
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: backup-config
  namespace: clm-backup
data:
  backup.policy: |
    {
      "databases": {
        "postgresql": {
          "frequency": "daily",
          "retention": "30d",
          "compression": "gzip",
          "encryption": "AES256"
        },
        "mongodb": {
          "frequency": "daily",
          "retention": "30d",
          "compression": "gzip",
          "encryption": "AES256"
        }
      },
      "object_storage": {
        "artefacts": {
          "frequency": "daily",
          "retention": "365d",
          "versioning": true,
          "lifecycle": "standard"
        }
      },
      "disaster_recovery": {
        "replication": "cross_region",
        "rpo": "15m",
        "rto": "4h"
      }
    }
```

## 6. Network Architecture

### 6.1 VPC Configuration

#### Virtual Private Cloud
```yaml
apiVersion: ec2.aws.crossplane.io/v1alpha1
kind: VPC
metadata:
  name: clm-vpc
  namespace: clm-network
spec:
  forProvider:
    region: us-east-1
    cidrBlock: "10.0.0.0/16"
    enableDnsHostnames: true
    enableDnsSupport: true
    instanceTenancy: default
    tags:
      Name: clm-vpc
      Environment: production
      Project: clm-system
---
apiVersion: ec2.aws.crossplane.io/v1alpha1
kind: Subnet
metadata:
  name: clm-public-subnet-1
  namespace: clm-network
spec:
  forProvider:
    region: us-east-1
    vpcIdRef:
      name: clm-vpc
    cidrBlock: "10.0.1.0/24"
    availabilityZone: us-east-1a
    mapPublicIpOnLaunch: true
    tags:
      Name: clm-public-subnet-1
      Type: public
---
apiVersion: ec2.aws.crossplane.io/v1alpha1
kind: Subnet
metadata:
  name: clm-private-subnet-1
  namespace: clm-network
spec:
  forProvider:
    region: us-east-1
    vpcIdRef:
      name: clm-vpc
    cidrBlock: "10.0.10.0/24"
    availabilityZone: us-east-1a
    mapPublicIpOnLaunch: false
    tags:
      Name: clm-private-subnet-1
      Type: private
```

### 6.2 Security Groups

#### Security Group Configuration
```yaml
apiVersion: ec2.aws.crossplane.io/v1alpha1
kind: SecurityGroup
metadata:
  name: clm-web-sg
  namespace: clm-network
spec:
  forProvider:
    region: us-east-1
    description: "Security group for web tier"
    vpcIdRef:
      name: clm-vpc
    ingress:
      - description: "HTTPS from internet"
        fromPort: 443
        toPort: 443
        ipProtocol: tcp
        cidrBlocks: ["0.0.0.0/0"]
      - description: "HTTP from internet"
        fromPort: 80
        toPort: 80
        ipProtocol: tcp
        cidrBlocks: ["0.0.0.0/0"]
    egress:
      - description: "All outbound traffic"
        ipProtocol: "-1"
        cidrBlocks: ["0.0.0.0/0"]
    tags:
      Name: clm-web-sg
      Tier: web
---
apiVersion: ec2.aws.crossplane.io/v1alpha1
kind: SecurityGroup
metadata:
  name: clm-app-sg
  namespace: clm-network
spec:
  forProvider:
    region: us-east-1
    description: "Security group for application tier"
    vpcIdRef:
      name: clm-vpc
    ingress:
      - description: "HTTPS from web tier"
        fromPort: 8080
        toPort: 8080
        ipProtocol: tcp
        securityGroups: [clm-web-sg]
      - description: "HTTP from web tier"
        fromPort: 8000
        toPort: 8000
        ipProtocol: tcp
        securityGroups: [clm-web-sg]
    egress:
      - description: "Database access"
        fromPort: 5432
        toPort: 5432
        ipProtocol: tcp
        securityGroups: [clm-db-sg]
      - description: "Redis access"
        fromPort: 6379
        toPort: 6379
        ipProtocol: tcp
        securityGroups: [clm-cache-sg]
    tags:
      Name: clm-app-sg
      Tier: application
```

## 7. Monitoring Infrastructure

### 7.1 Prometheus Configuration

#### Prometheus Cluster
```yaml
apiVersion: monitoring.coreos.com/v1
kind: Prometheus
metadata:
  name: prometheus
  namespace: clm-monitoring
spec:
  serviceAccountName: prometheus
  serviceMonitorSelector:
    matchLabels:
      team: clm
  ruleSelector:
    matchLabels:
      team: clm
  replicas: 2
  resources:
    requests:
      memory: 400Mi
      cpu: 100m
    limits:
      memory: 2Gi
      cpu: 1000m
  retention: 30d
  storage:
    volumeClaimTemplate:
      spec:
        storageClassName: gp3-encrypted
        resources:
          requests:
            storage: 50Gi
---
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: customer-service-monitor
  namespace: clm-system
  labels:
    team: clm
spec:
  selector:
    matchLabels:
      app: customer-service
  endpoints:
  - port: http
    path: /metrics
    interval: 30s
    scrapeTimeout: 10s
```

### 7.2 Grafana Configuration

#### Grafana Dashboard
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: grafana
  namespace: clm-monitoring
spec:
  replicas: 2
  selector:
    matchLabels:
      app: grafana
  template:
    metadata:
      labels:
        app: grafana
    spec:
      containers:
      - name: grafana
        image: grafana/grafana:9.3.0
        ports:
        - containerPort: 3000
        env:
        - name: GF_SECURITY_ADMIN_USER
          valueFrom:
            secretKeyRef:
              name: grafana-credentials
              key: admin-user
        - name: GF_SECURITY_ADMIN_PASSWORD
          valueFrom:
            secretKeyRef:
              name: grafana-credentials
              key: admin-password
        - name: GF_INSTALL_PLUGINS
          value: "grafana-piechart-panel,grafana-worldmap-panel"
        resources:
          requests:
            memory: "256Mi"
            cpu: "100m"
          limits:
            memory: "512Mi"
            cpu: "200m"
        volumeMounts:
        - name: grafana-storage
          mountPath: /var/lib/grafana
      volumes:
      - name: grafana-storage
        persistentVolumeClaim:
          claimName: grafana-pvc
```

## 8. Logging Infrastructure

### 8.1 ELK Stack Configuration

#### Elasticsearch Cluster
```yaml
apiVersion: elasticsearch.k8s.elastic.co/v1
kind: Elasticsearch
metadata:
  name: elasticsearch
  namespace: clm-logging
spec:
  version: 8.5.0
  nodeSets:
  - name: master
    count: 3
    config:
      node.roles: ["master"]
      xpack.security.enabled: true
    podTemplate:
      spec:
        containers:
        - name: elasticsearch
          resources:
            requests:
              memory: 2Gi
              cpu: 1000m
            limits:
              memory: 4Gi
              cpu: 2000m
          env:
          - name: ES_JAVA_OPTS
            value: "-Xms2g -Xmx2g"
    volumeClaimTemplates:
    - metadata:
        name: elasticsearch-data
      spec:
        accessModes: ["ReadWriteOnce"]
        storageClassName: gp3-encrypted
        resources:
          requests:
            storage: 100Gi
  - name: data
    count: 3
    config:
      node.roles: ["data", "ingest"]
      xpack.security.enabled: true
    podTemplate:
      spec:
        containers:
        - name: elasticsearch
          resources:
            requests:
              memory: 4Gi
              cpu: 2000m
            limits:
              memory: 8Gi
              cpu: 4000m
          env:
          - name: ES_JAVA_OPTS
            value: "-Xms4g -Xmx4g"
    volumeClaimTemplates:
    - metadata:
        name: elasticsearch-data
      spec:
        accessModes: ["ReadWriteOnce"]
        storageClassName: gp3-encrypted
        resources:
          requests:
            storage: 500Gi
```

### 8.2 Logstash Configuration

#### Logstash Pipeline
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: logstash
  namespace: clm-logging
spec:
  replicas: 3
  selector:
    matchLabels:
      app: logstash
  template:
    metadata:
      labels:
        app: logstash
    spec:
      containers:
      - name: logstash
        image: docker.elastic.co/logstash/logstash:8.5.0
        ports:
        - containerPort: 5044
          name: beats
        - containerPort: 9600
          name: http
        env:
        - name: LS_JAVA_OPTS
          value: "-Xmx1g -Xms1g"
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        volumeMounts:
        - name: config
          mountPath: /usr/share/logstash/pipeline
      volumes:
      - name: config
        configMap:
          name: logstash-config
```

## 9. CI/CD Infrastructure

### 9.1 Build Pipeline

#### Jenkins Configuration
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: jenkins
  namespace: clm-cicd
spec:
  replicas: 2
  selector:
    matchLabels:
      app: jenkins
  template:
    metadata:
      labels:
        app: jenkins
    spec:
      containers:
      - name: jenkins
        image: jenkins/jenkins:lts
        ports:
        - containerPort: 8080
        - containerPort: 50000
        env:
        - name: JAVA_OPTS
          value: "-Djenkins.install.runSetupWizard=false"
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        volumeMounts:
        - name: jenkins-home
          mountPath: /var/jenkins_home
      volumes:
      - name: jenkins-home
        persistentVolumeClaim:
          claimName: jenkins-pvc
```

### 9.2 ArgoCD Configuration

#### GitOps Deployment
```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: clm-system
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/clm-banking/infrastructure
    targetRevision: HEAD
    path: kubernetes/clm-system
  destination:
    server: https://kubernetes.default.svc
    namespace: clm-system
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
    - CreateNamespace=true
```

## 10. Security Infrastructure

### 10.1 Network Policies

#### Security Policy Configuration
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: clm-network-policy
  namespace: clm-system
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: clm-ingress
    ports:
    - protocol: TCP
      port: 8080
  - from:
    - namespaceSelector:
        matchLabels:
          name: clm-monitoring
    ports:
    - protocol: TCP
      port: 8080
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          name: clm-database
    ports:
    - protocol: TCP
      port: 5432
  - to:
    - namespaceSelector:
        matchLabels:
          name: clm-cache
    ports:
    - protocol: TCP
      port: 6379
```

### 10.2 Pod Security Policies

#### Security Policy
```yaml
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  name: clm-restricted-psp
  namespace: clm-system
spec:
  privileged: false
  allowPrivilegeEscalation: false
  requiredDropCapabilities:
    - ALL
  volumes:
    - 'configMap'
    - 'emptyDir'
    - 'projected'
    - 'secret'
    - 'downwardAPI'
    - 'persistentVolumeClaim'
  runAsUser:
    rule: 'MustRunAsNonRoot'
  seLinux:
    rule: 'RunAsAny'
  fsGroup:
    rule: 'RunAsAny'
```

## 11. Disaster Recovery

### 11.1 Backup Strategy

#### Automated Backup Configuration
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: database-backup
  namespace: clm-backup
spec:
  schedule: "0 2 * * *"
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: postgres-backup
            image: postgres:14
            command:
            - /bin/bash
            - -c
            - |
              pg_dump -h $POSTGRES_HOST -U $POSTGRES_USER -d $POSTGRES_DB | \
              gzip > /backup/$(date +%Y%m%d_%H%M%S).sql.gz
              aws s3 cp /backup/$(date +%Y%m%d_%H%M%S).sql.gz \
              s3://clm-backups/postgres/
            env:
            - name: POSTGRES_HOST
              value: postgres-cluster-rw
            - name: POSTGRES_USER
              valueFrom:
                secretKeyRef:
                  name: postgres-credentials
                  key: username
            - name: POSTGRES_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: postgres-credentials
                  key: password
            - name: POSTGRES_DB
              value: clm
            volumeMounts:
            - name: backup-storage
              mountPath: /backup
          volumes:
          - name: backup-storage
            emptyDir: {}
          restartPolicy: OnFailure
```

### 11.2 Disaster Recovery Plan

#### Recovery Procedures
```bash
#!/bin/bash
# Disaster Recovery Script

# 1. Switch DNS to disaster recovery region
aws route53 change-resource-record-sets \
  --hosted-zone-id ZXXXXXXXXXXXXX \
  --change-batch file://dr-dns-change.json

# 2. Scale up disaster recovery infrastructure
kubectl scale deployment --replicas=6 customer-service -n clm-system-dr
kubectl scale deployment --replicas=6 account-service -n clm-system-dr

# 3. Restore database from latest backup
kubectl apply -f dr-postgres-restore.yaml

# 4. Verify system health
kubectl get pods -n clm-system-dr
kubectl exec -it postgres-cluster-1 -n clm-database-dr -- psql -c "SELECT count(*) FROM customers"

# 5. Run smoke tests
./run-smoke-tests.sh dr-region

echo "Disaster recovery completed successfully"
```

## 12. Infrastructure as Code

### 12.1 Terraform Configuration

#### Main Configuration
```hcl
terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 4.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.0"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.0"
    }
  }
  
  backend "s3" {
    bucket = "clm-terraform-state"
    key    = "infrastructure/terraform.tfstate"
    region = "us-east-1"
    encrypt = true
  }
}

provider "aws" {
  region = var.aws_region
  
  default_tags {
    tags = {
      Environment = var.environment
      Project     = "clm-system"
      ManagedBy   = "terraform"
    }
  }
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.cluster.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.cluster.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.cluster.token
}

# VPC Configuration
module "vpc" {
  source = "terraform-aws-modules/vpc/aws"
  
  name = "clm-vpc"
  cidr = "10.0.0.0/16"
  
  azs             = ["us-east-1a", "us-east-1b", "us-east-1c"]
  private_subnets = ["10.0.10.0/24", "10.0.20.0/24", "10.0.30.0/24"]
  public_subnets  = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  
  enable_nat_gateway = true
  enable_vpn_gateway = false
  
  tags = {
    Name = "clm-vpc"
  }
}

# EKS Cluster
module "eks_cluster" {
  source = "terraform-aws-modules/eks/aws"
  
  cluster_name    = "clm-cluster"
  cluster_version = "1.24"
  
  subnets = module.vpc.private_subnets
  vpc_id  = module.vpc.vpc_id
  
  node_groups = {
    application_nodes = {
      desired_capacity = 3
      max_capacity     = 6
      min_capacity     = 3
      instance_type    = "m5.xlarge"
      k8s_labels = {
        Environment = "production"
        NodePool    = "application"
      }
    }
    
    database_nodes = {
      desired_capacity = 3
      max_capacity     = 6
      min_capacity     = 3
      instance_type    = "r5.2xlarge"
      k8s_labels = {
        Environment = "production"
        NodePool    = "database"
      }
    }
  }
}
```

This comprehensive infrastructure architecture provides a robust, scalable, and secure foundation for the Customer Lifecycle Management system with proper disaster recovery, monitoring, and compliance capabilities.
