# API Interface Catalog - Customer Lifecycle Management

## API Overview

The Customer Lifecycle Management system exposes a comprehensive set of RESTful APIs following OpenAPI 3.0 specification. All APIs use JSON for request/response format and implement proper HTTP status codes.

## Base URL Structure
```
Production: https://api.clm-banking.com/api/v1
Staging: https://api-staging.clm-banking.com/api/v1
Development: https://api-dev.clm-banking.com/api/v1
```

## Authentication

All API endpoints require authentication using JWT tokens:
```
Authorization: Bearer <JWT_TOKEN>
```

## Rate Limiting
- **General**: 1000 requests per 15 minutes
- **Authentication**: 5 requests per 15 minutes
- **Transactions**: 10 requests per minute
- **Uploads**: 5 requests per minute

## Customer Service APIs

### Customer Management

#### Create Customer
```http
POST /customers
Content-Type: application/json
Authorization: Bearer <token>

{
  "first_name": "John",
  "last_name": "Doe",
  "date_of_birth": "1990-01-01",
  "nationality": "US",
  "gender": "M",
  "email": "john.doe@example.com",
  "phone": "+1234567890",
  "address": {
    "street": "123 Main St",
    "city": "New York",
    "state": "NY",
    "postal_code": "10001",
    "country": "US"
  },
  "preferences": {
    "language": "en",
    "timezone": "America/New_York",
    "communication_channel": "email"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "first_name": "John",
    "last_name": "Doe",
    "email": "john.doe@example.com",
    "verification_status": "pending",
    "risk_profile": {
      "risk_score": 5,
      "risk_category": "medium"
    },
    "created_at": "2024-01-01T00:00:00Z",
    "status": "active"
  },
  "message": "Customer created successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Get Customer
```http
GET /customers/{customer_id}
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "personal_info": {
      "first_name": "John",
      "last_name": "Doe",
      "date_of_birth": "1990-01-01",
      "nationality": "US",
      "gender": "M"
    },
    "contact_info": {
      "email": "john.doe@example.com",
      "phone": "+1234567890",
      "address": {
        "street": "123 Main St",
        "city": "New York",
        "state": "NY",
        "postal_code": "10001",
        "country": "US"
      }
    },
    "verification_status": "verified",
    "risk_profile": {
      "risk_score": 3,
      "risk_category": "low"
    },
    "preferences": {
      "language": "en",
      "timezone": "America/New_York",
      "communication_channel": "email"
    },
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
    "status": "active"
  },
  "message": "Customer retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Update Customer
```http
PUT /customers/{customer_id}
Content-Type: application/json
Authorization: Bearer <token>

{
  "contact_info": {
    "phone": "+1234567891",
    "address": {
      "street": "124 Main St",
      "city": "New York",
      "state": "NY",
      "postal_code": "10001",
      "country": "US"
    }
  },
  "preferences": {
    "communication_channel": "both"
  }
}
```

#### Delete Customer
```http
DELETE /customers/{customer_id}
Authorization: Bearer <token>
```

### Customer Profile

#### Get Customer Profile
```http
GET /customers/{customer_id}/profile
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "profile_completion": 85,
    "personal_info_complete": true,
    "contact_info_complete": true,
    "preferences_complete": true,
    "kyc_complete": true,
    "accounts_count": 3,
    "last_login": "2024-01-01T00:00:00Z",
    "engagement_score": 75,
    "risk_tier": "low"
  },
  "message": "Profile retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Update Customer Preferences
```http
PUT /customers/{customer_id}/preferences
Content-Type: application/json
Authorization: Bearer <token>

{
  "language": "es",
  "timezone": "America/Mexico_City",
  "communication_channel": "sms",
  "marketing_consent": true,
  "data_sharing_consent": false
}
```

## Onboarding Service APIs

### Onboarding Management

#### Start Onboarding
```http
POST /onboarding/start
Content-Type: application/json
Authorization: Bearer <token>

{
  "customer_id": "550e8400-e29b-41d4-a716-446655440000",
  "onboarding_type": "digital",
  "product_interests": ["checking", "savings", "credit_card"]
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "onboarding_id": "660e8400-e29b-41d4-a716-446655440001",
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "current_step": 1,
    "total_steps": 5,
    "estimated_completion_time": "15 minutes",
    "status": "in_progress",
    "started_at": "2024-01-01T00:00:00Z"
  },
  "message": "Onboarding started successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Get Onboarding Status
```http
GET /onboarding/{onboarding_id}/status
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "onboarding_id": "660e8400-e29b-41d4-a716-446655440001",
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "current_step": 3,
    "total_steps": 5,
    "step_status": {
      "personal_info": true,
      "contact_info": true,
      "identity_verification": true,
      "kyc_completion": false,
      "account_selection": false
    },
    "progress_percentage": 60,
    "estimated_remaining_time": "5 minutes",
    "status": "in_progress",
    "started_at": "2024-01-01T00:00:00Z"
  },
  "message": "Onboarding status retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Complete Onboarding Step
```http
POST /onboarding/{onboarding_id}/step
Content-Type: application/json
Authorization: Bearer <token>

{
  "step": "identity_verification",
  "data": {
    "document_type": "passport",
    "document_number": "P123456789",
    "consent": true
  }
}
```

#### Upload Onboarding Documents
```http
POST /onboarding/{onboarding_id}/documents
Content-Type: multipart/form-data
Authorization: Bearer <token>

documents: [File]
document_type: "passport"
```

## Account Service APIs

### Account Management

#### Create Account
```http
POST /accounts
Content-Type: application/json
Authorization: Bearer <token>

{
  "customer_id": "550e8400-e29b-41d4-a716-446655440000",
  "account_type": "checking",
  "currency": "USD",
  "initial_deposit": 1000.00,
  "product_preferences": {
    "debit_card": true,
    "online_banking": true,
    "mobile_banking": true
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "account_id": "770e8400-e29b-41d4-a716-446655440002",
    "account_number": "1234567890123456",
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "account_type": "checking",
    "currency": "USD",
    "balance": 1000.00,
    "available_balance": 1000.00,
    "status": "active",
    "created_at": "2024-01-01T00:00:00Z"
  },
  "message": "Account created successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Get Account Details
```http
GET /accounts/{account_id}
Authorization: Bearer <token>
```

#### Update Account
```http
PUT /accounts/{account_id}
Content-Type: application/json
Authorization: Bearer <token>

{
  "limits": {
    "daily_transaction_limit": 15000.00,
    "monthly_transaction_limit": 150000.00,
    "daily_withdrawal_limit": 7500.00
  }
}
```

#### Close Account
```http
POST /accounts/{account_id}/close
Content-Type: application/json
Authorization: Bearer <token>

{
  "reason": "customer_request",
  "final_disposition": "transfer_to_account_123456",
  "confirmation": true
}
```

### Product Management

#### Get Account Products
```http
GET /accounts/{account_id}/products
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "product_id": "880e8400-e29b-41d4-a716-446655440003",
      "product_code": "DEBIT_CARD_STANDARD",
      "product_name": "Standard Debit Card",
      "product_type": "debit_card",
      "status": "active",
      "terms": {
        "annual_fee": 0.00,
        "daily_limit": 2500.00,
        "monthly_limit": 7500.00
      },
      "activated_at": "2024-01-01T00:00:00Z"
    }
  ],
  "message": "Products retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Add Product to Account
```http
POST /accounts/{account_id}/products
Content-Type: application/json
Authorization: Bearer <token>

{
  "product_code": "CREDIT_CARD_PLATINUM",
  "product_preferences": {
    "credit_limit": 10000.00,
    "additional_cardholders": ["spouse"]
  }
}
```

## Transaction Service APIs

### Transaction Processing

#### Create Transaction
```http
POST /transactions
Content-Type: application/json
Authorization: Bearer <token>

{
  "account_id": "770e8400-e29b-41d4-a716-446655440002",
  "transaction_type": "debit",
  "amount": 150.00,
  "currency": "USD",
  "description": "Grocery Store Purchase",
  "merchant_details": {
    "name": "Whole Foods Market",
    "category": "groceries",
    "location": "New York, NY"
  }
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "transaction_id": "990e8400-e29b-41d4-a716-446655440004",
    "account_id": "770e8400-e29b-41d4-a716-446655440002",
    "transaction_type": "debit",
    "amount": 150.00,
    "currency": "USD",
    "description": "Grocery Store Purchase",
    "reference_number": "TXN20240101001",
    "status": "pending",
    "created_at": "2024-01-01T00:00:00Z"
  },
  "message": "Transaction created successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Get Transaction Details
```http
GET /transactions/{transaction_id}
Authorization: Bearer <token>
```

#### Get Account Transactions
```http
GET /accounts/{account_id}/transactions?limit=50&offset=0&start_date=2024-01-01&end_date=2024-01-31
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "transaction_id": "990e8400-e29b-41d4-a716-446655440004",
        "transaction_type": "debit",
        "amount": 150.00,
        "currency": "USD",
        "description": "Grocery Store Purchase",
        "merchant_name": "Whole Foods Market",
        "category": "groceries",
        "status": "completed",
        "created_at": "2024-01-01T00:00:00Z",
        "completed_at": "2024-01-01T00:00:05Z"
      }
    ],
    "pagination": {
      "total": 25,
      "limit": 50,
      "offset": 0,
      "has_more": false
    }
  },
  "message": "Transactions retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Cancel Transaction
```http
POST /transactions/{transaction_id}/cancel
Content-Type: application/json
Authorization: Bearer <token>

{
  "reason": "customer_request",
  "confirmation": true
}
```

### Transfer Operations

#### Initiate Transfer
```http
POST /transfers
Content-Type: application/json
Authorization: Bearer <token>

{
  "from_account_id": "770e8400-e29b-41d4-a716-446655440002",
  "to_account_id": "770e8400-e29b-41d4-a716-446655440003",
  "amount": 500.00,
  "currency": "USD",
  "description": "Monthly Rent Payment",
  "scheduled_date": "2024-01-01"
}
```

#### Confirm Transfer
```http
POST /transfers/{transfer_id}/confirm
Content-Type: application/json
Authorization: Bearer <token>

{
  "confirmation_code": "123456",
  "biometric_token": "base64_encoded_token"
}
```

## Compliance Service APIs

### KYC Management

#### Initiate KYC Verification
```http
POST /kyc/initiate
Content-Type: application/json
Authorization: Bearer <token>

{
  "customer_id": "550e8400-e29b-41d4-a716-446655440000",
  "verification_type": "identity",
  "consent": true,
  "preferred_method": "digital"
}
```

#### Get KYC Status
```http
GET /kyc/{customer_id}
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "kyc_records": [
      {
        "kyc_id": "101e8400-e29b-41d4-a716-446655440005",
        "verification_type": "identity",
        "verification_status": "verified",
        "risk_score": 3,
        "risk_factors": [],
        "documents": [
          {
            "document_id": "201e8400-e29b-41d4-a716-446655440006",
            "document_type": "passport",
            "verification_status": "verified",
            "upload_timestamp": "2024-01-01T00:00:00Z"
          }
        ],
        "verified_at": "2024-01-01T00:05:00Z",
        "expires_at": "2025-01-01T00:00:00Z"
      }
    ],
    "overall_status": "verified",
    "last_updated": "2024-01-01T00:05:00Z"
  },
  "message": "KYC status retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Upload KYC Documents
```http
POST /kyc/{customer_id}/documents
Content-Type: multipart/form-data
Authorization: Bearer <token>

documents: [File]
document_type: "passport"
verification_type: "identity"
```

### AML Screening

#### Screen Customer
```http
POST /aml/screen
Content-Type: application/json
Authorization: Bearer <token>

{
  "customer_id": "550e8400-e29b-41d4-a716-446655440000",
  "screening_types": ["sanctions", "pep", "adverse_media"],
  "consent": true
}
```

#### Get Screening Results
```http
GET /aml/{customer_id}/results
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "screening_results": [
      {
        "check_id": "301e8400-e29b-41d4-a716-446655440007",
        "check_type": "sanctions",
        "match_found": false,
        "risk_level": "low",
        "status": "completed",
        "performed_at": "2024-01-01T00:00:00Z"
      }
    ],
    "overall_risk_level": "low",
    "review_required": false
  },
  "message": "Screening results retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

## Notification Service APIs

### Notification Management

#### Send Notification
```http
POST /notifications/send
Content-Type: application/json
Authorization: Bearer <token>

{
  "customer_id": "550e8400-e29b-41d4-a716-446655440000",
  "channel": "email",
  "template": "transaction_confirmation",
  "data": {
    "transaction_amount": 150.00,
    "merchant_name": "Whole Foods Market",
    "account_balance": 2500.00
  },
  "priority": "normal"
}
```

#### Get Notification History
```http
GET /notifications/{customer_id}?limit=20&offset=0&channel=email
Authorization: Bearer <token>
```

## Analytics Service APIs

### Business Intelligence

#### Get Customer Metrics
```http
GET /analytics/customers/{customer_id}/metrics?period=30d
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "customer_id": "550e8400-e29b-41d4-a716-446655440000",
    "period": "30d",
    "metrics": {
      "transaction_count": 45,
      "total_spent": 3250.00,
      "average_transaction": 72.22,
      "most_used_category": "groceries",
      "login_frequency": 12,
      "engagement_score": 78,
      "risk_trend": "stable"
    },
    "trends": [
      {
        "date": "2024-01-01",
        "transaction_count": 3,
        "total_spent": 125.50
      }
    ]
  },
  "message": "Customer metrics retrieved successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

#### Get System Metrics
```http
GET /analytics/system/metrics?period=24h
Authorization: Bearer <token>
```

## Error Responses

### Standard Error Format
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable error message",
    "details": {
      "field": "field_name",
      "reason": "Specific error reason"
    }
  },
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "req_123456789"
}
```

### Common Error Codes
- `VALIDATION_ERROR`: Invalid input data
- `AUTHENTICATION_ERROR`: Invalid or missing authentication
- `AUTHORIZATION_ERROR`: Insufficient permissions
- `NOT_FOUND`: Resource not found
- `CONFLICT`: Resource conflict
- `RATE_LIMIT_EXCEEDED`: Too many requests
- `INTERNAL_SERVER_ERROR`: System error
- `SERVICE_UNAVAILABLE`: Service temporarily unavailable

## API Versioning

### Version Strategy
- **URL Versioning**: `/api/v1/`, `/api/v2/`
- **Semantic Versioning**: MAJOR.MINOR.PATCH
- **Backward Compatibility**: Support at least 2 previous versions
- **Deprecation Notice**: 6 months deprecation period

### Version Changes
- **Major**: Breaking changes, requires migration
- **Minor**: New features, backward compatible
- **Patch**: Bug fixes, security updates

## API Security

### Authentication
- **JWT Tokens**: Stateless authentication
- **Token Expiration**: 15 minutes access tokens
- **Refresh Tokens**: 30 days refresh tokens
- **Token Rotation**: Automatic refresh token rotation

### Authorization
- **RBAC**: Role-based access control
- **Scopes**: Fine-grained permissions
- **Resource-based**: Resource-level access control
- **Time-based**: Temporary access grants

### Rate Limiting
- **Per User**: Individual user limits
- **Per IP**: IP-based limits
- **Per Endpoint**: Endpoint-specific limits
- **Burst Handling**: Short-term burst capacity

## API Monitoring

### Key Metrics
- **Request Rate**: Requests per second
- **Response Time**: P50, P95, P99 percentiles
- **Error Rate**: Percentage of failed requests
- **Availability**: Uptime percentage
- **Throughput**: Data transfer volume

### Health Checks
```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00Z",
  "version": "1.0.0",
  "services": {
    "database": "healthy",
    "cache": "healthy",
    "message_queue": "healthy",
    "external_apis": "healthy"
  }
}
```

## API Documentation

### OpenAPI Specification
- **Specification**: OpenAPI 3.0
- **Interactive Docs**: Swagger UI
- **Code Generation**: Client SDK generation
- **Validation**: Request/response validation

### Documentation Access
- **Swagger UI**: `/api/docs`
- **OpenAPI JSON**: `/api/docs.json`
- **Postman Collection**: Available for download
- **SDK Examples**: Multiple programming languages

## API Testing

### Test Environment
- **Sandbox**: `/api-sandbox.clm-banking.com`
- **Test Data**: Mock data for testing
- **Rate Limits**: Relaxed limits for testing
- **Webhooks**: Test webhook endpoints

### Test Scenarios
- **Happy Path**: Normal operation flows
- **Error Cases**: Invalid inputs, failures
- **Edge Cases**: Boundary conditions
- **Load Testing**: Performance under load

## API Support

### Contact Information
- **Technical Support**: api-support@clm-banking.com
- **Documentation**: docs.clm-banking.com/api
- **Status Page**: status.clm-banking.com
- **Community**: community.clm-banking.com

### Support Channels
- **Email**: Non-urgent issues
- **Phone**: Urgent production issues
- **Chat**: Real-time support
- **Ticket**: Issue tracking system
