# Customer Lifecycle Management - Low-Level Design (LLD)

## 1. Service Design Patterns

### 1.1 Customer Service (Node.js/Express)

#### 1.1.1 Service Structure
```
src/
├── controllers/
│   ├── customerController.js
│   ├── profileController.js
│   └── onboardingController.js
├── services/
│   ├── customerService.js
│   ├── profileService.js
│   └── onboardingService.js
├── repositories/
│   ├── customerRepository.js
│   └── profileRepository.js
├── models/
│   ├── Customer.js
│   ├── Profile.js
│   └── Onboarding.js
├── middleware/
│   ├── auth.js
│   ├── validation.js
│   └── rateLimit.js
├── utils/
│   ├── logger.js
│   ├── crypto.js
│   └── validators.js
└── config/
    ├── database.js
    ├── redis.js
    └── kafka.js
```

#### 1.1.2 API Endpoints
```javascript
// Customer Management
POST   /api/v1/customers              // Create new customer
GET    /api/v1/customers/:id          // Get customer details
PUT    /api/v1/customers/:id          // Update customer
DELETE /api/v1/customers/:id          // Delete customer

// Profile Management
GET    /api/v1/customers/:id/profile  // Get customer profile
PUT    /api/v1/customers/:id/profile  // Update profile
POST   /api/v1/customers/:id/preferences // Update preferences

// Onboarding
POST   /api/v1/onboarding/start       // Start onboarding process
GET    /api/v1/onboarding/:id/status  // Get onboarding status
POST   /api/v1/onboarding/:id/step    // Complete onboarding step
PUT    /api/v1/onboarding/:id/documents // Upload documents
```

#### 1.1.3 Data Models
```javascript
// Customer Model
const CustomerSchema = {
  customer_id: { type: UUID, primary: true },
  personal_info: {
    first_name: { type: String, required: true },
    last_name: { type: String, required: true },
    date_of_birth: { type: Date, required: true },
    nationality: { type: String, required: true },
    gender: { type: String, enum: ['M', 'F', 'O'] }
  },
  contact_info: {
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    address: {
      street: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String, required: true },
      postal_code: { type: String, required: true },
      country: { type: String, required: true }
    }
  },
  verification_status: { 
    type: String, 
    enum: ['pending', 'verified', 'rejected'], 
    default: 'pending' 
  },
  risk_profile: {
    risk_score: { type: Number, min: 1, max: 10 },
    risk_category: { type: String, enum: ['low', 'medium', 'high'] }
  },
  preferences: {
    language: { type: String, default: 'en' },
    timezone: { type: String, default: 'UTC' },
    communication_channel: { type: String, enum: ['email', 'sms', 'both'] }
  },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'suspended'], 
    default: 'active' 
  }
};

// Onboarding Model
const OnboardingSchema = {
  onboarding_id: { type: UUID, primary: true },
  customer_id: { type: UUID, required: true, ref: 'Customer' },
  current_step: { type: Number, default: 1 },
  total_steps: { type: Number, default: 5 },
  step_status: {
    personal_info: { type: Boolean, default: false },
    contact_info: { type: Boolean, default: false },
    identity_verification: { type: Boolean, default: false },
    kyc_completion: { type: Boolean, default: false },
    account_selection: { type: Boolean, default: false }
  },
  documents: [{
    document_id: { type: UUID, required: true },
    document_type: { type: String, required: true },
    file_path: { type: String, required: true },
    upload_timestamp: { type: Date, default: Date.now },
    verification_status: { type: String, enum: ['pending', 'verified', 'rejected'] }
  }],
  started_at: { type: Date, default: Date.now },
  completed_at: { type: Date },
  status: { 
    type: String, 
    enum: ['in_progress', 'completed', 'abandoned'], 
    default: 'in_progress' 
  }
};
```

### 1.2 Account Service (Node.js/Express)

#### 1.2.1 Service Structure
```
src/
├── controllers/
│   ├── accountController.js
│   ├── productController.js
│   └── balanceController.js
├── services/
│   ├── accountService.js
│   ├── productService.js
│   └── balanceService.js
├── repositories/
│   ├── accountRepository.js
│   ├── productRepository.js
│   └── balanceRepository.js
├── models/
│   ├── Account.js
│   ├── Product.js
│   └── Balance.js
└── events/
    ├── accountEvents.js
    └── productEvents.js
```

#### 1.2.2 API Endpoints
```javascript
// Account Management
POST   /api/v1/accounts                // Create new account
GET    /api/v1/accounts/:id            // Get account details
PUT    /api/v1/accounts/:id            // Update account
POST   /api/v1/accounts/:id/close      // Close account

// Product Management
GET    /api/v1/accounts/:id/products   // Get account products
POST   /api/v1/accounts/:id/products   // Add product to account
PUT    /api/v1/products/:id             // Update product
DELETE /api/v1/products/:id             // Remove product

// Balance Management
GET    /api/v1/accounts/:id/balance    // Get account balance
GET    /api/v1/accounts/:id/transactions // Get transaction history
POST   /api/v1/accounts/:id/limits     // Set account limits
```

#### 1.2.3 Data Models
```javascript
// Account Model
const AccountSchema = {
  account_id: { type: UUID, primary: true },
  customer_id: { type: UUID, required: true, ref: 'Customer' },
  account_number: { type: String, required: true, unique: true },
  account_type: { 
    type: String, 
    enum: ['checking', 'savings', 'credit', 'investment'], 
    required: true 
  },
  currency: { type: String, required: true, default: 'USD' },
  balance: { type: Number, default: 0 },
  available_balance: { type: Number, default: 0 },
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'frozen', 'closed'], 
    default: 'active' 
  },
  limits: {
    daily_transaction_limit: { type: Number, default: 10000 },
    monthly_transaction_limit: { type: Number, default: 100000 },
    daily_withdrawal_limit: { type: Number, default: 5000 }
  },
  created_at: { type: Date, default: Date.now },
  closed_at: { type: Date }
};

// Product Model
const ProductSchema = {
  product_id: { type: UUID, primary: true },
  account_id: { type: UUID, required: true, ref: 'Account' },
  product_code: { type: String, required: true },
  product_name: { type: String, required: true },
  product_type: { 
    type: String, 
    enum: ['debit_card', 'credit_card', 'loan', 'investment'], 
    required: true 
  },
  terms: {
    interest_rate: { type: Number },
    annual_fee: { type: Number },
    credit_limit: { type: Number },
    minimum_balance: { type: Number }
  },
  status: { 
    type: String, 
    enum: ['active', 'inactive', 'blocked'], 
    default: 'active' 
  },
  created_at: { type: Date, default: Date.now },
  activated_at: { type: Date }
};
```

### 1.3 Transaction Service (Node.js/Express)

#### 1.3.1 Service Structure
```
src/
├── controllers/
│   ├── transactionController.js
│   ├── transferController.js
│   └── paymentController.js
├── services/
│   ├── transactionService.js
│   ├── transferService.js
│   └── paymentService.js
├── repositories/
│   ├── transactionRepository.js
│   └── balanceRepository.js
├── models/
│   ├── Transaction.js
│   ├── Transfer.js
│   └── Payment.js
├── validators/
│   ├── transactionValidator.js
│   └── balanceValidator.js
└── events/
    ├── transactionEvents.js
    └── balanceEvents.js
```

#### 1.3.2 API Endpoints
```javascript
// Transaction Processing
POST   /api/v1/transactions            // Create transaction
GET    /api/v1/transactions/:id        // Get transaction details
GET    /api/v1/accounts/:id/transactions // Get account transactions
POST   /api/v1/transactions/:id/cancel // Cancel transaction

// Transfers
POST   /api/v1/transfers               // Initiate transfer
GET    /api/v1/transfers/:id          // Get transfer details
POST   /api/v1/transfers/:id/confirm  // Confirm transfer
POST   /api/v1/transfers/:id/cancel   // Cancel transfer

// Payments
POST   /api/v1/payments                // Process payment
GET    /api/v1/payments/:id            // Get payment details
POST   /api/v1/payments/:id/refund     // Refund payment
```

#### 1.3.3 Data Models
```javascript
// Transaction Model
const TransactionSchema = {
  transaction_id: { type: UUID, primary: true },
  account_id: { type: UUID, required: true, ref: 'Account' },
  transaction_type: { 
    type: String, 
    enum: ['debit', 'credit', 'transfer', 'payment'], 
    required: true 
  },
  amount: { type: Number, required: true, min: 0.01 },
  currency: { type: String, required: true },
  description: { type: String, required: true },
  reference_number: { type: String, unique: true },
  status: { 
    type: String, 
    enum: ['pending', 'processing', 'completed', 'failed', 'cancelled'], 
    default: 'pending' 
  },
  metadata: {
    merchant_name: { type: String },
    category: { type: String },
    tags: [String],
    notes: { type: String }
  },
  created_at: { type: Date, default: Date.now },
  processed_at: { type: Date },
  completed_at: { type: Date }
};

// Transfer Model
const TransferSchema = {
  transfer_id: { type: UUID, primary: true },
  from_account_id: { type: UUID, required: true, ref: 'Account' },
  to_account_id: { type: UUID, required: true, ref: 'Account' },
  amount: { type: Number, required: true, min: 0.01 },
  currency: { type: String, required: true },
  description: { type: String, required: true },
  status: { 
    type: String, 
    enum: ['pending', 'processing', 'completed', 'failed', 'cancelled'], 
    default: 'pending' 
  },
  fees: {
    transfer_fee: { type: Number, default: 0 },
    currency_conversion_fee: { type: Number, default: 0 }
  },
  exchange_rate: { type: Number },
  created_at: { type: Date, default: Date.now },
  completed_at: { type: Date }
};
```

### 1.4 Compliance Service (Node.js/Express)

#### 1.4.1 Service Structure
```
src/
├── controllers/
│   ├── kycController.js
│   ├── amlController.js
│   └── complianceController.js
├── services/
│   ├── kycService.js
│   ├── amlService.js
│   └── complianceService.js
├── repositories/
│   ├── kycRepository.js
│   └── complianceRepository.js
├── models/
│   ├── KYCRecord.js
│   ├── AMLCheck.js
│   └── ComplianceCheck.js
├── integrations/
│   ├── identityVerification.js
│   ├── sanctionsScreening.js
│   └── creditBureau.js
└── events/
    ├── complianceEvents.js
    └── auditEvents.js
```

#### 1.4.2 API Endpoints
```javascript
// KYC Management
POST   /api/v1/kyc/initiate            // Initiate KYC process
GET    /api/v1/kyc/:customer_id        // Get KYC status
POST   /api/v1/kyc/:customer_id/documents // Upload KYC documents
GET    /api/v1/kyc/:customer_id/verify  // Verify KYC information

// AML Screening
POST   /api/v1/aml/screen               // Screen customer
GET    /api/v1/aml/:customer_id/results // Get screening results
POST   /api/v1/aml/:customer_id/review  // Review screening results

// Compliance
GET    /api/v1/compliance/checklist     // Get compliance checklist
POST   /api/v1/compliance/report        // Generate compliance report
GET    /api/v1/compliance/audit         // Get audit trail
```

#### 1.4.3 Data Models
```javascript
// KYC Record Model
const KYCRecordSchema = {
  kyc_id: { type: UUID, primary: true },
  customer_id: { type: UUID, required: true, ref: 'Customer' },
  verification_type: { 
    type: String, 
    enum: ['identity', 'address', 'income', 'employment'], 
    required: true 
  },
  documents: [{
    document_id: { type: UUID, required: true },
    document_type: { type: String, required: true },
    file_path: { type: String, required: true },
    upload_timestamp: { type: Date, default: Date.now },
    verification_status: { type: String, enum: ['pending', 'verified', 'rejected'] },
    verification_details: {
      verified_by: { type: String },
      verification_timestamp: { type: Date },
      rejection_reason: { type: String }
    }
  }],
  verification_status: { 
    type: String, 
    enum: ['pending', 'verified', 'rejected', 'expired'], 
    default: 'pending' 
  },
  risk_score: { type: Number, min: 1, max: 10 },
  risk_factors: [String],
  verified_at: { type: Date },
  expires_at: { type: Date },
  created_at: { type: Date, default: Date.now }
};

// AML Check Model
const AMLCheckSchema = {
  check_id: { type: UUID, primary: true },
  customer_id: { type: UUID, required: true, ref: 'Customer' },
  check_type: { 
    type: String, 
    enum: ['sanctions', 'pep', 'adverse_media', 'transaction_monitoring'], 
    required: true 
  },
  screening_result: {
    match_found: { type: Boolean, default: false },
    match_details: [{
      source: { type: String },
      confidence: { type: Number, min: 0, max: 100 },
      details: { type: Object }
    }],
    risk_level: { type: String, enum: ['low', 'medium', 'high'] }
  },
  status: { 
    type: String, 
    enum: ['pending', 'completed', 'requires_review'], 
    default: 'pending' 
  },
  performed_at: { type: Date, default: Date.now },
  performed_by: { type: String },
  review_required: { type: Boolean, default: false },
  review_details: {
    reviewed_by: { type: String },
    review_timestamp: { type: Date },
    review_decision: { type: String, enum: ['approve', 'reject', 'escalate'] },
    review_notes: { type: String }
  }
};
```

## 2. Database Design

### 2.1 PostgreSQL Schema

#### 2.1.1 Customer Tables
```sql
-- Customers Table
CREATE TABLE customers (
    customer_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    nationality VARCHAR(3) NOT NULL,
    gender CHAR(1) CHECK (gender IN ('M', 'F', 'O')),
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    street_address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20) NOT NULL,
    country VARCHAR(3) NOT NULL,
    verification_status VARCHAR(20) DEFAULT 'pending',
    risk_score INTEGER CHECK (risk_score >= 1 AND risk_score <= 10),
    risk_category VARCHAR(10) CHECK (risk_category IN ('low', 'medium', 'high')),
    preferred_language VARCHAR(5) DEFAULT 'en',
    timezone VARCHAR(50) DEFAULT 'UTC',
    communication_channel VARCHAR(10) DEFAULT 'email',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active',
    CONSTRAINT customers_status_check CHECK (status IN ('active', 'inactive', 'suspended'))
);

-- Accounts Table
CREATE TABLE accounts (
    account_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(customer_id),
    account_number VARCHAR(20) NOT NULL UNIQUE,
    account_type VARCHAR(20) NOT NULL,
    currency VARCHAR(3) NOT NULL DEFAULT 'USD',
    balance DECIMAL(15,2) DEFAULT 0.00,
    available_balance DECIMAL(15,2) DEFAULT 0.00,
    daily_transaction_limit DECIMAL(15,2) DEFAULT 10000.00,
    monthly_transaction_limit DECIMAL(15,2) DEFAULT 100000.00,
    daily_withdrawal_limit DECIMAL(15,2) DEFAULT 5000.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active',
    CONSTRAINT accounts_status_check CHECK (status IN ('active', 'inactive', 'frozen', 'closed')),
    CONSTRAINT accounts_type_check CHECK (account_type IN ('checking', 'savings', 'credit', 'investment'))
);

-- Products Table
CREATE TABLE products (
    product_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES accounts(account_id),
    product_code VARCHAR(50) NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    product_type VARCHAR(20) NOT NULL,
    interest_rate DECIMAL(5,4),
    annual_fee DECIMAL(10,2),
    credit_limit DECIMAL(15,2),
    minimum_balance DECIMAL(15,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activated_at TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active',
    CONSTRAINT products_status_check CHECK (status IN ('active', 'inactive', 'blocked')),
    CONSTRAINT products_type_check CHECK (product_type IN ('debit_card', 'credit_card', 'loan', 'investment'))
);

-- Transactions Table
CREATE TABLE transactions (
    transaction_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id UUID NOT NULL REFERENCES accounts(account_id),
    transaction_type VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL CHECK (amount > 0),
    currency VARCHAR(3) NOT NULL,
    description VARCHAR(255) NOT NULL,
    reference_number VARCHAR(50) UNIQUE,
    merchant_name VARCHAR(100),
    category VARCHAR(50),
    tags TEXT[],
    notes TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    completed_at TIMESTAMP,
    CONSTRAINT transactions_status_check CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')),
    CONSTRAINT transactions_type_check CHECK (transaction_type IN ('debit', 'credit', 'transfer', 'payment'))
);
```

#### 2.1.2 Compliance Tables
```sql
-- KYC Records Table
CREATE TABLE kyc_records (
    kyc_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(customer_id),
    verification_type VARCHAR(20) NOT NULL,
    verification_status VARCHAR(20) DEFAULT 'pending',
    risk_score INTEGER CHECK (risk_score >= 1 AND risk_score <= 10),
    risk_factors TEXT[],
    verified_at TIMESTAMP,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT kyc_status_check CHECK (verification_status IN ('pending', 'verified', 'rejected', 'expired')),
    CONSTRAINT kyc_type_check CHECK (verification_type IN ('identity', 'address', 'income', 'employment'))
);

-- KYC Documents Table
CREATE TABLE kyc_documents (
    document_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kyc_id UUID NOT NULL REFERENCES kyc_records(kyc_id),
    document_type VARCHAR(50) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INTEGER,
    file_type VARCHAR(50),
    upload_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verification_status VARCHAR(20) DEFAULT 'pending',
    verified_by VARCHAR(100),
    verification_timestamp TIMESTAMP,
    rejection_reason TEXT,
    CONSTRAINT kyc_docs_status_check CHECK (verification_status IN ('pending', 'verified', 'rejected'))
);

-- AML Checks Table
CREATE TABLE aml_checks (
    check_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL REFERENCES customers(customer_id),
    check_type VARCHAR(30) NOT NULL,
    match_found BOOLEAN DEFAULT FALSE,
    risk_level VARCHAR(10),
    status VARCHAR(20) DEFAULT 'pending',
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    performed_by VARCHAR(100),
    review_required BOOLEAN DEFAULT FALSE,
    reviewed_by VARCHAR(100),
    review_timestamp TIMESTAMP,
    review_decision VARCHAR(20),
    review_notes TEXT,
    CONSTRAINT aml_status_check CHECK (status IN ('pending', 'completed', 'requires_review')),
    CONSTRAINT aml_type_check CHECK (check_type IN ('sanctions', 'pep', 'adverse_media', 'transaction_monitoring')),
    CONSTRAINT aml_decision_check CHECK (review_decision IN ('approve', 'reject', 'escalate'))
);
```

### 2.2 MongoDB Collections

#### 2.2.1 Document Collections
```javascript
// Onboarding Collection
{
  _id: ObjectId,
  onboarding_id: String,
  customer_id: String,
  current_step: Number,
  total_steps: Number,
  step_status: {
    personal_info: Boolean,
    contact_info: Boolean,
    identity_verification: Boolean,
    kyc_completion: Boolean,
    account_selection: Boolean
  },
  documents: [{
    document_id: String,
    document_type: String,
    file_path: String,
    upload_timestamp: Date,
    verification_status: String
  }],
  started_at: Date,
  completed_at: Date,
  status: String,
  metadata: Object
}

// Audit Log Collection
{
  _id: ObjectId,
  audit_id: String,
  user_id: String,
  action: String,
  resource_type: String,
  resource_id: String,
  timestamp: Date,
  ip_address: String,
  user_agent: String,
  request_details: Object,
  response_details: Object,
  success: Boolean,
  error_details: Object
}

// Configuration Collection
{
  _id: ObjectId,
  config_type: String,
  config_key: String,
  config_value: Object,
  description: String,
  is_active: Boolean,
  created_at: Date,
  updated_at: Date,
  updated_by: String
}
```

## 3. API Design Specifications

### 3.1 REST API Standards

#### 3.1.1 Request/Response Format
```javascript
// Standard Response Format
{
  "success": true,
  "data": {},
  "message": "Operation completed successfully",
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "uuid"
}

// Error Response Format
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "field": "email",
      "reason": "Invalid email format"
    }
  },
  "timestamp": "2024-01-01T00:00:00Z",
  "request_id": "uuid"
}
```

#### 3.1.2 HTTP Status Codes
- `200 OK`: Successful GET, PUT, DELETE
- `201 Created`: Successful POST
- `400 Bad Request`: Validation errors
- `401 Unauthorized`: Authentication required
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `409 Conflict`: Resource conflicts
- `422 Unprocessable Entity`: Business logic errors
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: System errors

### 3.2 Authentication & Authorization

#### 3.2.1 JWT Token Structure
```javascript
// JWT Payload
{
  "sub": "customer_id",
  "role": "customer",
  "permissions": ["read:profile", "write:profile"],
  "iat": 1640995200,
  "exp": 1641081600,
  "iss": "clm-system",
  "aud": "clm-api"
}
```

#### 3.2.2 Role-Based Access Control
```javascript
// Role Definitions
const ROLES = {
  CUSTOMER: {
    permissions: [
      'read:own_profile',
      'write:own_profile',
      'read:own_accounts',
      'write:own_transactions'
    ]
  },
  STAFF: {
    permissions: [
      'read:customers',
      'write:customers',
      'read:accounts',
      'write:accounts',
      'read:transactions'
    ]
  },
  ADMIN: {
    permissions: [
      '*'
    ]
  }
};
```

## 4. Integration Specifications

### 4.1 External API Integrations

#### 4.1.1 Identity Verification Service
```javascript
// API Integration
const identityVerification = {
  endpoint: 'https://api.identity-verify.com/v1/verify',
  method: 'POST',
  headers: {
    'Authorization': 'Bearer API_KEY',
    'Content-Type': 'application/json'
  },
  requestBody: {
    document_type: 'passport',
    document_number: 'PASSPORT_NUMBER',
    date_of_birth: '1990-01-01',
    nationality: 'US'
  },
  response: {
    verification_status: 'verified',
    confidence_score: 95,
    match_details: {
      name_match: true,
      dob_match: true,
      photo_match: true
    }
  }
};
```

#### 4.1.2 Credit Bureau Integration
```javascript
// Credit Bureau API
const creditBureau = {
  endpoint: 'https://api.credit-bureau.com/v1/credit-report',
  method: 'POST',
  headers: {
    'Authorization': 'Bearer API_KEY',
    'Content-Type': 'application/json'
  },
  requestBody: {
    ssn: 'SOCIAL_SECURITY_NUMBER',
    date_of_birth: '1990-01-01',
    address: {
      street: '123 Main St',
      city: 'New York',
      state: 'NY',
      zip: '10001'
    }
  },
  response: {
    credit_score: 750,
    credit_report: {
      payment_history: 'excellent',
      credit_utilization: 25,
      account_age: 10
    }
  }
};
```

### 4.2 Message Queue Events

#### 4.2.1 Event Schema
```javascript
// Customer Events
const customerEvents = {
  'customer.created': {
    customer_id: 'UUID',
    email: 'customer@example.com',
    phone: '+1234567890',
    timestamp: '2024-01-01T00:00:00Z'
  },
  'customer.verified': {
    customer_id: 'UUID',
    verification_type: 'identity',
    verification_status: 'verified',
    timestamp: '2024-01-01T00:00:00Z'
  },
  'customer.onboarding.completed': {
    customer_id: 'UUID',
    onboarding_id: 'UUID',
    completion_time: '2024-01-01T00:00:00Z'
  }
};

// Transaction Events
const transactionEvents = {
  'transaction.initiated': {
    transaction_id: 'UUID',
    account_id: 'UUID',
    amount: 100.00,
    currency: 'USD',
    timestamp: '2024-01-01T00:00:00Z'
  },
  'transaction.completed': {
    transaction_id: 'UUID',
    status: 'completed',
    processed_at: '2024-01-01T00:00:00Z'
  },
  'transaction.failed': {
    transaction_id: 'UUID',
    error_code: 'INSUFFICIENT_FUNDS',
    error_message: 'Insufficient funds',
    timestamp: '2024-01-01T00:00:00Z'
  }
};
```

## 5. Performance Optimization

### 5.1 Database Optimization

#### 5.1.1 Indexing Strategy
```sql
-- Customer Table Indexes
CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_status ON customers(status);
CREATE INDEX idx_customers_created_at ON customers(created_at);
CREATE INDEX idx_customers_verification_status ON customers(verification_status);

-- Accounts Table Indexes
CREATE INDEX idx_accounts_customer_id ON accounts(customer_id);
CREATE INDEX idx_accounts_account_number ON accounts(account_number);
CREATE INDEX idx_accounts_status ON accounts(status);
CREATE INDEX idx_accounts_created_at ON accounts(created_at);

-- Transactions Table Indexes
CREATE INDEX idx_transactions_account_id ON transactions(account_id);
CREATE INDEX idx_transactions_created_at ON transactions(created_at);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_reference_number ON transactions(reference_number);
```

#### 5.1.2 Query Optimization
```javascript
// Optimized Customer Query
const getCustomerWithAccounts = async (customerId) => {
  const query = `
    SELECT 
      c.*,
      a.account_id,
      a.account_number,
      a.account_type,
      a.balance,
      a.status as account_status
    FROM customers c
    LEFT JOIN accounts a ON c.customer_id = a.customer_id
    WHERE c.customer_id = $1 AND c.status = 'active'
  `;
  
  return await db.query(query, [customerId]);
};

// Optimized Transaction Query
const getAccountTransactions = async (accountId, limit = 50, offset = 0) => {
  const query = `
    SELECT 
      transaction_id,
      transaction_type,
      amount,
      currency,
      description,
      created_at,
      status
    FROM transactions
    WHERE account_id = $1 AND status = 'completed'
    ORDER BY created_at DESC
    LIMIT $2 OFFSET $3
  `;
  
  return await db.query(query, [accountId, limit, offset]);
};
```

### 5.2 Caching Strategy

#### 5.2.1 Redis Cache Implementation
```javascript
// Cache Service
class CacheService {
  constructor(redisClient) {
    this.redis = redisClient;
    this.defaultTTL = 3600; // 1 hour
  }

  async get(key) {
    try {
      const value = await this.redis.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      console.error('Cache get error:', error);
      return null;
    }
  }

  async set(key, value, ttl = this.defaultTTL) {
    try {
      await this.redis.setex(key, ttl, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error('Cache set error:', error);
      return false;
    }
  }

  async del(key) {
    try {
      await this.redis.del(key);
      return true;
    } catch (error) {
      console.error('Cache delete error:', error);
      return false;
    }
  }

  // Cache key patterns
  static keys = {
    customer: (id) => `customer:${id}`,
    account: (id) => `account:${id}`,
    transactions: (accountId) => `transactions:${accountId}`,
    kyc: (customerId) => `kyc:${customerId}`,
    session: (token) => `session:${token}`
  };
}

// Cache Usage Examples
const customerCache = new CacheService(redisClient);

// Get customer with cache
const getCustomer = async (customerId) => {
  const cacheKey = CacheService.keys.customer(customerId);
  let customer = await customerCache.get(cacheKey);
  
  if (!customer) {
    customer = await customerRepository.findById(customerId);
    if (customer) {
      await customerCache.set(cacheKey, customer);
    }
  }
  
  return customer;
};

// Invalidate cache on update
const updateCustomer = async (customerId, updateData) => {
  const customer = await customerRepository.update(customerId, updateData);
  const cacheKey = CacheService.keys.customer(customerId);
  await customerCache.del(cacheKey);
  return customer;
};
```

## 6. Security Implementation

### 6.1 Input Validation

#### 6.1.1 Validation Middleware
```javascript
// Validation Middleware
const validate = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: error.details.map(detail => ({
            field: detail.path.join('.'),
            reason: detail.message
          }))
        }
      });
    }
    next();
  };
};

// Validation Schemas
const customerSchema = Joi.object({
  first_name: Joi.string().min(2).max(100).required(),
  last_name: Joi.string().min(2).max(100).required(),
  date_of_birth: Joi.date().max('now').required(),
  email: Joi.string().email().required(),
  phone: Joi.string().pattern(/^\+?[1-9]\d{1,14}$/).required(),
  address: Joi.object({
    street: Joi.string().min(5).max(255).required(),
    city: Joi.string().min(2).max(100).required(),
    state: Joi.string().min(2).max(100).required(),
    postal_code: Joi.string().min(3).max(20).required(),
    country: Joi.string().length(2).required()
  }).required()
});
```

### 6.2 Rate Limiting

#### 6.2.1 Rate Limiting Implementation
```javascript
// Rate Limiting Middleware
const rateLimit = require('express-rate-limit');

const createRateLimit = (windowMs, max, message) => {
  return rateLimit({
    windowMs,
    max,
    message: {
      success: false,
      error: {
        code: 'RATE_LIMIT_EXCEEDED',
        message
      }
    },
    standardHeaders: true,
    legacyHeaders: false
  });
};

// Rate Limiting Rules
const rateLimits = {
  general: createRateLimit(15 * 60 * 1000, 100, 'Too many requests'),
  auth: createRateLimit(15 * 60 * 1000, 5, 'Too many authentication attempts'),
  transactions: createRateLimit(60 * 1000, 10, 'Too many transaction requests'),
  uploads: createRateLimit(60 * 1000, 5, 'Too many upload requests')
};
```

## 7. Error Handling

### 7.1 Error Types

#### 7.1.1 Custom Error Classes
```javascript
// Base Error Class
class BaseError extends Error {
  constructor(message, statusCode, code) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

// Specific Error Types
class ValidationError extends BaseError {
  constructor(message, details) {
    super(message, 400, 'VALIDATION_ERROR');
    this.details = details;
  }
}

class NotFoundError extends BaseError {
  constructor(resource, id) {
    super(`${resource} with id ${id} not found`, 404, 'NOT_FOUND');
    this.resource = resource;
    this.id = id;
  }
}

class UnauthorizedError extends BaseError {
  constructor(message = 'Unauthorized') {
    super(message, 401, 'UNAUTHORIZED');
  }
}

class ForbiddenError extends BaseError {
  constructor(message = 'Forbidden') {
    super(message, 403, 'FORBIDDEN');
  }
}

class ConflictError extends BaseError {
  constructor(message, details) {
    super(message, 409, 'CONFLICT');
    this.details = details;
  }
}
```

### 7.2 Error Handling Middleware

#### 7.2.1 Global Error Handler
```javascript
// Error Handling Middleware
const errorHandler = (err, req, res, next) => {
  let error = { ...err };
  error.message = err.message;

  // Log error
  console.error(err);

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const message = 'Validation Error';
    const details = Object.values(err.errors).map(val => ({
      field: val.path,
      reason: val.message
    }));
    error = new ValidationError(message, details);
  }

  // Mongoose duplicate key error
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    const value = err.keyValue[field];
    const message = `${field} with value ${value} already exists`;
    error = new ConflictError(message, { field, value });
  }

  // Mongoose cast error
  if (err.name === 'CastError') {
    const message = 'Invalid ID format';
    error = new ValidationError(message);
  }

  // Send error response
  res.status(error.statusCode || 500).json({
    success: false,
    error: {
      code: error.code || 'INTERNAL_SERVER_ERROR',
      message: error.message || 'Internal server error',
      details: error.details || null
    },
    timestamp: new Date().toISOString(),
    request_id: req.id
  });
};
```

## 8. Testing Strategy

### 8.1 Unit Testing

#### 8.1.1 Service Layer Tests
```javascript
// Customer Service Tests
describe('CustomerService', () => {
  let customerService;
  let mockCustomerRepository;

  beforeEach(() => {
    mockCustomerRepository = {
      create: jest.fn(),
      findById: jest.fn(),
      update: jest.fn(),
      delete: jest.fn()
    };
    customerService = new CustomerService(mockCustomerRepository);
  });

  describe('createCustomer', () => {
    it('should create a new customer successfully', async () => {
      const customerData = {
        first_name: 'John',
        last_name: 'Doe',
        email: 'john.doe@example.com',
        phone: '+1234567890',
        date_of_birth: '1990-01-01',
        address: {
          street: '123 Main St',
          city: 'New York',
          state: 'NY',
          postal_code: '10001',
          country: 'US'
        }
      };

      const expectedCustomer = {
        customer_id: 'uuid',
        ...customerData,
        verification_status: 'pending',
        created_at: new Date(),
        status: 'active'
      };

      mockCustomerRepository.create.mockResolvedValue(expectedCustomer);

      const result = await customerService.createCustomer(customerData);

      expect(mockCustomerRepository.create).toHaveBeenCalledWith(customerData);
      expect(result).toEqual(expectedCustomer);
    });

    it('should throw validation error for invalid email', async () => {
      const customerData = {
        first_name: 'John',
        last_name: 'Doe',
        email: 'invalid-email',
        phone: '+1234567890',
        date_of_birth: '1990-01-01',
        address: {
          street: '123 Main St',
          city: 'New York',
          state: 'NY',
          postal_code: '10001',
          country: 'US'
        }
      };

      await expect(customerService.createCustomer(customerData))
        .rejects
        .toThrow(ValidationError);
    });
  });
});
```

### 8.2 Integration Testing

#### 8.2.1 API Integration Tests
```javascript
// Customer API Tests
describe('Customer API', () => {
  let app;
  let server;

  beforeAll(async () => {
    app = createApp();
    server = app.listen(0);
  });

  afterAll(async () => {
    await server.close();
  });

  describe('POST /api/v1/customers', () => {
    it('should create a new customer', async () => {
      const customerData = {
        first_name: 'John',
        last_name: 'Doe',
        email: 'john.doe@example.com',
        phone: '+1234567890',
        date_of_birth: '1990-01-01',
        address: {
          street: '123 Main St',
          city: 'New York',
          state: 'NY',
          postal_code: '10001',
          country: 'US'
        }
      };

      const response = await request(app)
        .post('/api/v1/customers')
        .send(customerData)
        .expect(201);

      expect(response.body.success).toBe(true);
      expect(response.body.data.email).toBe(customerData.email);
      expect(response.body.data.verification_status).toBe('pending');
    });

    it('should return validation error for invalid data', async () => {
      const invalidData = {
        first_name: '',
        email: 'invalid-email'
      };

      const response = await request(app)
        .post('/api/v1/customers')
        .send(invalidData)
        .expect(400);

      expect(response.body.success).toBe(false);
      expect(response.body.error.code).toBe('VALIDATION_ERROR');
    });
  });
});
```

This comprehensive LLD provides detailed specifications for implementing the Customer Lifecycle Management system with proper separation of concerns, security measures, and performance optimizations.
