# Data Architecture Patterns

> Patterns that define how data is modelled, stored, accessed, cached, partitioned, and governed across a system. These patterns cover everything from individual service data stores to enterprise-wide analytics and master data management.

---

### Star Schema

**Description:** A dimensional data modelling pattern used in data warehouses where a central fact table containing measurable business events is surrounded by dimension tables providing descriptive context (who, what, when, where). The resulting schema resembles a star shape.

**Use Cases:** Modelling a verification check analytics in an analytics platform with a Fact_KYC_Checks table at the centre linked to Dim_Customer, Dim_KYC_Provider, Dim_Date, and Dim_Decision_Outcome dimensions. a BI reporting tool regulatory reports requiring fast, simple join queries against a dimensional model.

**Benefits:** Provides fast query performance for analytical workloads with simple, predictable join patterns between fact and dimension tables that query optimisers handle efficiently. Highly intuitive for business users and report developers who can understand the model without deep database knowledge.

---

---

### Data Vault 2.0

**Description:** A detail-oriented, historical-tracking, uniquely linked, normalised database modelling methodology for data warehouses, composed of Hubs (unique business keys), Links (relationships between business keys), and Satellites (descriptive attributes with full history). Designed for auditability and adaptability.

**Use Cases:** Enterprise data warehouse platforms in regulated industries (banking, insurance) where every historical state of every data relationship must be preserved and auditable for regulatory examination. Environments with frequent source system changes where a flexible, schema-evolution-friendly model is required.

**Benefits:** Provides a complete, immutable history of all data relationships and attribute changes with no data overwriting, satisfying the strictest regulatory auditability requirements. The highly normalised, pattern-based structure accommodates schema changes in source systems by adding new Satellites without restructuring existing tables.

---

---

### Data Lake

**Description:** A centralised repository that stores vast amounts of raw data in its native format — structured, semi-structured, and unstructured — at any scale, with schema applied on read rather than on write. Data is ingested without transformation and transformed only when queried for a specific purpose.

**Use Cases:** Storing all raw the platform events — onboarding events, identity verification documents, audit logs, application logs — in cloud Data Lake Storage Gen2 in their original format for future analytics, ML model training, and regulatory forensic analysis. Ingesting raw data from multiple source systems for exploratory data analysis before designing the formal data warehouse model.

**Benefits:** Enables storage of all data at low cost without requiring upfront schema design, preserving raw data that might become valuable for future use cases not anticipated at ingestion time. Supports diverse analytical use cases including SQL queries, ML training, and graph analytics over the same raw data store.

---

---

### Data Lakehouse

**Description:** A modern data architecture that combines the low-cost, flexible raw storage of a Data Lake with the data management, ACID transactions, and query performance capabilities of a Data Warehouse, using open table formats (Delta Lake, Apache Iceberg) on top of object storage.

**Use Cases:** The platform an analytics platform where raw event data is stored in Delta Lake format on cloud Data Lake, enabling ACID transactions for incremental ETL updates, time travel queries for point-in-time regulatory analysis, and SQL queries via Synapse Spark without a separate warehouse. Replacing separate data lake and data warehouse tiers with a single unified platform.

**Benefits:** Eliminates the complexity and data duplication of maintaining separate data lake and data warehouse systems, reducing operational overhead and storage costs. ACID transactions on the object store enable reliable incremental data updates without full table rewrites, dramatically improving ETL efficiency.

---

---

### Data Mesh

**Description:** A sociotechnical approach to data architecture that applies microservices-style domain ownership to data, treating data as a product owned by the domain team that produces it, distributed across domains rather than centralised in a monolithic data warehouse. Governed by federated computational governance.

**Use Cases:** Large banking organisations where the customer domain team, the identity verification compliance team, the product team, and the analytics team each own and publish their own data products — Customer Data Product, identity verification Decisions Data Product, Account Events Data Product — consumed by other teams via a data marketplace. Replacing a centralised data team bottleneck with domain-owned data products.

**Benefits:** Eliminates the centralised data team bottleneck by distributing data ownership to the teams closest to the data, dramatically improving data quality and time-to-insight. Treating data as a product with SLAs, documentation, and versioning ensures data consumers get reliable, high-quality data assets.

---

---

### Polyglot Persistence

**Description:** An architectural approach where different microservices or components use different data storage technologies — relational, document, key-value, graph, time-series — each chosen as the best fit for that service's specific data access patterns and consistency requirements.

**Use Cases:** The platform using a NoSQL document store (document store) for the flexible Customer Profile, a managed relational database (relational) for ACID-compliant identity verification and transactional data, a managed cache service (key-value) for session and idempotency key caching, and object storage (object store) for identity verification document files. Each service independently optimised for its data model.

**Benefits:** Allows each service to use the storage technology optimally suited to its data model and access pattern, avoiding the performance and modelling compromises of forcing all data into a single database type. Enables independent evolution of each service's persistence tier without affecting other services.

---

---

### Cache-Aside

**Description:** A caching pattern where the application is responsible for loading data into the cache on a cache miss — the cache sits "aside" from the main data store. On a read, the application checks the cache first; if not found, it reads from the database and populates the cache with the result.

**Use Cases:** Caching a unified entity view read model results in a managed cache service — an internal staff portal checks the cache service first; on a miss, queries the application backend API, then stores the result in the cache service with a 5-minute TTL. Caching reference data (product catalogue, country codes, risk tier definitions) that changes infrequently.

**Benefits:** Dramatically reduces read latency and database load for frequently accessed data by serving repeated reads from the in-memory cache. The application retains full control over cache population and invalidation, enabling cache-busting strategies precisely when the underlying data changes.

---

---

### Write-Through Cache

**Description:** A caching pattern where every write to the primary data store is simultaneously written to the cache by the cache layer itself, ensuring the cache is always consistent with the store. Reads always hit the cache which is guaranteed to reflect the latest written state.

**Use Cases:** Caching customer risk ratings that must be consistent between the compliance verification service write path and an internal staff portal read path — every identity verification decision write updates both the database and the cache atomically. Session data that is both written and read frequently and must always reflect the latest state.

**Benefits:** Eliminates cache invalidation complexity — the cache is always current because it is updated synchronously with every write. Provides consistent, low-latency reads without the risk of serving stale data from the cache.

---

---

### Write-Behind Cache

**Description:** A caching pattern where writes are first made to the cache and asynchronously flushed to the primary data store by the cache layer, improving write throughput by batching or delaying writes to the slower persistent store.

**Use Cases:** High-frequency session activity updates — such as updating a customer's last-seen timestamp with every portal interaction — where the overhead of a synchronous database write on every page load is unacceptable. Write-heavy analytics counters that are aggregated in cache and periodically flushed to the database.

**Benefits:** Dramatically improves write throughput and reduces database write latency for high-frequency, low-criticality writes by buffering them in the fast cache and writing to the database asynchronously. Reduces database write amplification by batching many small writes into fewer, larger database operations.

---

---

### Read-Through Cache

**Description:** A caching pattern where the cache itself is responsible for loading data from the primary data store on a cache miss, making the cache the single access point for reads from the application's perspective. The application always reads from the cache and never directly from the database.

**Use Cases:** A transparent caching layer in front of the Customer Profile a NoSQL document store, where the application only calls the cache and the cache transparently fetches from a NoSQL document store on misses. Simplifying application code by removing cache-check logic from every service method.

**Benefits:** Simplifies application code by providing a single data access interface — the application never directly accesses the database, reducing code complexity. Cache population is automatic and lazy, ensuring only actually-requested data is loaded into the limited cache memory.

---

---

### Data Sharding

**Description:** A horizontal scaling pattern that partitions a large dataset across multiple database instances (shards) based on a shard key, distributing both storage and query load across shards. Each shard holds a subset of the full dataset and operates independently.

**Use Cases:** Partitioning the platform a verification check history table across multiple database shards based on customer nationality region — UK customers on shard 1, EU on shard 2 — when a single database instance cannot handle the write throughput or storage requirements. High-volume time-series data partitioned by time range across shards.

**Benefits:** Enables horizontal scaling of database read and write throughput beyond the limits of a single database instance by distributing load across multiple shards. Allows each shard to be sized independently, enabling cost-efficient scaling of specific high-volume data partitions.

---

---

### Master Data Management (MDM)

**Description:** A technology-enabled discipline that provides authoritative, consistent, accurate, and accountable master data (customers, products, accounts, counterparties) shared across the enterprise, with a golden record that resolves duplicates and serves as the single source of truth.

**Use Cases:** Creating a single golden customer record in the platform a profile service that resolves the 18% duplicate customer problem across legacy core system and CRM, acting as the system of record for all customer identity data consumed by other banking systems. Enterprise-wide management of product, counterparty, and legal entity reference data shared across multiple business lines.

**Benefits:** Eliminates data quality issues — duplicates, inconsistencies, stale reference data — that cause downstream system errors, regulatory reporting defects, and poor customer experiences. Provides a single authoritative source of truth that all systems consume, eliminating reconciliation overhead between systems with conflicting records.

---

---

### Data Contract

**Description:** A formal, versioned agreement between a data producer and its consumers that specifies the schema, semantics, quality standards, SLAs, and ownership of a data asset. Data contracts make data interfaces explicit, testable, and governed — the equivalent of API contracts for data products.

**Use Cases:** The platform a profile service publishing a versioned data contract for its a DomainEntityCreated event, specifying every field, its type, nullability, and semantic meaning, used by consumer teams to generate validators and integration tests. Formalising the interface between the application backend's nightly ADF ETL and the Synapse Analytics data warehouse.

**Benefits:** Eliminates breaking schema changes that silently corrupt downstream consumers by making data interfaces explicit, versioned, and tested. Provides clear ownership and accountability for data quality, with the producer responsible for honouring the contract and consumers able to trust the data they receive.

---

---

### Feature Store

**Description:** A centralised repository for storing, managing, sharing, and serving machine learning features — engineered data transformations used as inputs to ML models — ensuring that the same feature computation logic is used consistently during model training and online inference.

**Use Cases:** Storing pre-computed customer risk features — transaction velocity, identity verification history, account age, behavioural patterns — in a feature store shared between the identity verification risk scoring ML model (batch training) and the real-time identity verification decision service (online inference). Enabling multiple ML models in a fraud detection platform to share the same feature definitions.

**Benefits:** Eliminates training-serving skew — the gap between features computed during training and at inference time — which is a leading cause of ML model performance degradation in production. Enables feature reuse across multiple models and teams, reducing redundant feature engineering effort.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
