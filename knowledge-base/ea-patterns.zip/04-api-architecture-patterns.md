# API Architecture Patterns

> Patterns that govern the design, exposure, security, and resilience of application programming interfaces. These patterns cover API styles, gateway strategies, versioning, authentication, and fault tolerance for API-based communication.

---

### REST (Representational State Transfer)

**Description:** An architectural style for distributed hypermedia systems that uses HTTP methods (GET, POST, PUT, PATCH, DELETE) to operate on resources identified by URIs, with stateless interactions and a uniform interface. REST resources are represented as JSON or XML and linked via hypermedia.

**Use Cases:** All the application backend APIs — onboarding, identity verification, customer profile, case management — exposed through the API gateway using standard HTTP verbs and resource URIs. Any client-server API where stateless, cacheable interactions over HTTP are appropriate and the client and server are independently deployable.

**Benefits:** Leverages the full capabilities of HTTP including caching, status codes, and content negotiation, reducing the amount of protocol-level infrastructure teams must build. The uniform interface and stateless constraint make REST APIs simple to consume, test, cache, and scale horizontally.

---

---

### GraphQL

**Description:** A query language and runtime for APIs that allows clients to request exactly the data they need in a single request, regardless of how many backend services must be queried to fulfil it. Clients define the shape of the response; the server executes the query against a typed schema.

**Use Cases:** A customer-facing portal and mobile app use cases where different clients need different data shapes from the same data sources, avoiding the over-fetching and under-fetching problems of REST. Aggregating data from multiple microservices — customer profile, accounts, identity verification status, cases — into a single GraphQL query response.

**Benefits:** Eliminates over-fetching and under-fetching by allowing clients to request exactly the fields they need, reducing payload size and the number of round trips. A single GraphQL endpoint replaces multiple REST endpoints, simplifying client integration and enabling flexible evolution of the API schema.

---

---

### gRPC

**Description:** A high-performance, open-source Remote Procedure Call (RPC) framework from Google that uses Protocol Buffers (protobuf) for interface definition and binary serialisation, running over HTTP/2. It supports bidirectional streaming, strong typing, and code generation in multiple languages.

**Use Cases:** High-frequency internal service-to-service communication within the application backend where the overhead of HTTP/1.1 JSON serialisation is a performance constraint — such as an onboarding service calling the profile service 100,000 times per day. Streaming APIs such as a live audit event stream from an audit service.

**Benefits:** Dramatically lower serialisation overhead compared to JSON over HTTP/1.1, with binary protobuf encoding and HTTP/2 multiplexing enabling significantly higher throughput and lower latency. Strong typing with code generation from .proto files eliminates integration contract mismatches at compile time.

---

---

### SOAP / WS-*

**Description:** A messaging protocol for exchanging structured information in web services using XML, with a standardised envelope format and a suite of WS-* standards (WS-Security, WS-AtomicTransaction, WS-ReliableMessaging) for enterprise-grade capabilities. Defined via WSDL contracts.

**Use Cases:** Legacy enterprise integration with external financial institutions, regulators, or SWIFT connectivity where SOAP/WS-* is the mandated protocol. Back-office banking systems built in the 2000s that expose WS-Security signed SOAP endpoints for regulatory reporting.

**Benefits:** Provides a formally defined, strongly typed contract via WSDL that supports tooling-based client generation and strict schema validation. WS-Security provides standardised message-level encryption and signing, meeting high-security enterprise integration requirements.

---

---

### AsyncAPI

**Description:** An open specification for defining and documenting asynchronous, event-driven APIs — such as message queues, topics, and streams — in the same way that OpenAPI defines REST APIs. AsyncAPI defines channels, messages, bindings, and schemas for event-driven interfaces.

**Use Cases:** Documenting all the platform domain event schemas published to a managed message broker — a DomainEntityCreated, KYCCheckCompleted, an EntityActivated — using an AsyncAPI specification that consumer teams can use to generate client code. Providing a machine-readable contract for all async integrations in an EDA platform.

**Benefits:** Provides a standardised, toolable contract for async APIs analogous to OpenAPI for REST, enabling documentation generation, code generation, and contract testing for event-driven integrations. Makes async integration contracts explicit and versioned, reducing the "who's sending what" uncertainty in EDA platforms.

---

---

### API Gateway

**Description:** A server that acts as the single entry point for all API consumers, providing cross-cutting capabilities — authentication, rate limiting, request routing, SSL termination, response transformation, logging, and analytics — for all APIs behind it. The gateway decouples API consumers from backend services.

**Use Cases:** An API gateway acting as the single entry point for all the platform APIs, enforcing JWT validation, rate limiting per subscription, and request logging centrally without each microservice implementing these concerns. Managing multiple API versions and routing requests to the correct backend service version.

**Benefits:** Centralises all cross-cutting API concerns — security, throttling, logging, versioning — in one place, eliminating duplication across all backend services and ensuring consistent policy enforcement. Decouples the external API interface from the internal backend topology, allowing services to be refactored, split, or merged without affecting API consumers.

---

---

### API Facade

**Description:** A pattern where a dedicated API layer presents a simplified, consumer-friendly interface over a complex or legacy backend, translating the external API contract into the internal system's protocol, data model, and interaction patterns. The facade hides the complexity of the underlying system entirely.

**Use Cases:** Presenting a clean, modern REST JSON API over a legacy COBOL banking system that internally uses VSAM files and CICS transactions. Exposing a simplified Customer Profile API that internally aggregates data from five separate legacy tables without exposing the legacy data model to consumers.

**Benefits:** Allows legacy systems to be consumed as modern APIs without modifying the underlying system. Protects consumers from the complexity and instability of the backend, enabling the backend to be replaced incrementally without changing the external API contract.

---

---

### Rate Limiting

**Description:** An API protection pattern that restricts the number of requests a client can make to an API within a defined time window, returning HTTP 429 Too Many Requests when the limit is exceeded. Rate limits are enforced per client identity, subscription, or IP address.

**Use Cases:** Protecting the application backend identity verification API from a runaway client sending thousands of requests per second that would exhaust the third-party verification API quota and degrade service for all customers. Enforcing fair usage policies across multiple API subscribers sharing the same backend infrastructure.

**Benefits:** Protects backend services from being overwhelmed by excessive API traffic, maintaining availability and consistent performance for all consumers. Provides a mechanism for fair usage enforcement and commercial API product tiers — different rate limits for different subscription plans.

---

---

### Circuit Breaker

**Description:** A resilience pattern that monitors calls to a downstream service and trips open when the failure rate exceeds a threshold, immediately returning an error (or fallback) for subsequent calls without attempting to contact the failing service until a recovery probe succeeds.

**Use Cases:** Protecting the compliance verification service from cascading failure when a third-party identity verification API is slow or unavailable — the circuit breaker trips open after 5 failures in 60 seconds and routes new identity verification requests to a manual review queue rather than timing out for 30 seconds on every call. Preventing a slow the CRM platform from causing all onboarding completions to queue and exhaust thread pools.

**Benefits:** Prevents cascading failure propagation across microservices by failing fast when a dependency is unavailable, preserving resources for operations that can succeed. The open circuit state provides a recovery window for the downstream service, and the half-open probe allows automatic recovery without manual intervention.

---

---

### Retry with Exponential Backoff

**Description:** A resilience pattern where a failed operation is retried after an increasing delay (exponential backoff) with optional jitter to avoid thundering herd problems. The retry is only attempted for transient failures; permanent failures are not retried.

**Use Cases:** Retrying a failed HTTP call to the third-party verification API that returned a 503 Service Unavailable due to a momentary overload — retry after 1s, then 2s, then 4s, then 8s with jitter before declaring failure. Retrying a managed message broker message publishing after a transient network error.

**Benefits:** Automatically recovers from transient failures without requiring manual intervention or alert triage, improving system resilience and reducing on-call burden. Exponential backoff with jitter prevents the thundering herd problem where all retrying clients hit the recovering service simultaneously.

---

---

### Bulkhead

**Description:** A resilience pattern that isolates different consumers or types of requests into separate resource pools — thread pools, connection pools, or process groups — so that failure or resource exhaustion in one pool does not affect the availability of other pools. Named after the watertight compartments in a ship's hull.

**Use Cases:** Giving verification check requests a dedicated thread pool separate from the thread pool serving a unified entity view read requests, ensuring that a surge of identity verification requests cannot starve an internal staff portal of responsiveness. Isolating third-party verification API calls into a separate connection pool from sanctions screening provider calls.

**Benefits:** Prevents a single overloaded operation or dependency from exhausting the entire service's resources and causing complete unavailability. Enables differentiated SLAs — high-priority operations have their own resource pool protected from lower-priority workloads.

---

---

### Health Endpoint Monitoring

**Description:** A pattern where each service exposes a dedicated health check endpoint that reports its current operational status and the health of its dependencies, enabling load balancers, orchestrators, and monitoring systems to make routing and alerting decisions based on actual service health.

**Use Cases:** The container platform readiness and liveness probes calling the application framework Actuator /health endpoint to determine whether a pod is ready to receive traffic and whether it should be restarted. a global load balancer health probes hitting a /health endpoint to determine whether to route a customer-facing portal traffic to the primary or DR origin.

**Benefits:** Enables infrastructure — Kubernetes, load balancers, a global load balancer — to automatically route traffic away from unhealthy instances without human intervention. Provides a single, standardised mechanism for monitoring systems to determine service health, simplifying alerting and dashboard configuration.

---

---

### OAuth 2.0 / OIDC

**Description:** OAuth 2.0 is an authorisation framework that enables delegated access to resources using access tokens, while OpenID Connect (OIDC) adds an identity layer on top providing authentication via ID tokens. Together they form the modern standard for API security and federated identity.

**Use Cases:** A customer-facing portal authenticating customers via a customer identity provider using OIDC with PKCE, obtaining JWT access tokens for calling the application backend APIs secured by OAuth 2.0 Bearer token validation. an internal staff portal using an enterprise identity provider OIDC for SSO, with the JWT containing role claims used for RBAC enforcement in the API gateway and the security framework.

**Benefits:** Provides a standardised, widely-supported security framework that eliminates the need for every API to implement its own authentication mechanism. Token-based access enables fine-grained scoped permissions, short-lived credentials, and token revocation without requiring session state on the API server.

---

---

### mTLS (Mutual TLS)

**Description:** An extension of TLS where both the client and server present certificates to authenticate each other, providing mutual authentication in addition to the standard server-only authentication of TLS. Both parties must prove their identity before a connection is established.

**Use Cases:** Authenticating all machine-to-machine calls from the compliance verification service to a third-party identity verification API and a sanctions screening API, ensuring both that the platform system is the legitimate caller and that the API endpoint is the genuine provider. Authenticating all internal service-to-service calls within the container platform service mesh (a service mesh).

**Benefits:** Eliminates the risk of a rogue system impersonating a legitimate service client, providing strong mutual authentication that is independent of application-layer credentials. Certificate-based identity is harder to steal and reuse than shared API keys or passwords, significantly raising the bar for impersonation attacks.

---

---

### PKCE (Proof Key for Code Exchange)

**Description:** An OAuth 2.0 security extension for public clients — mobile apps and single-page applications — that prevents authorisation code interception attacks by binding the authorisation request to a client-generated code verifier, which must be presented when exchanging the code for a token.

**Use Cases:** The platform a customer-facing portal (React SPA) implementing the PKCE flow with a customer identity provider to prevent auth code interception by malicious JavaScript running in the browser. All public client OAuth flows — mobile banking apps, SPAs — where the client secret cannot be kept confidential.

**Benefits:** Prevents authorisation code interception attacks that are possible when auth codes are returned via browser redirects, without requiring a client secret. Enables secure OAuth 2.0 flows from public clients that cannot store client secrets, covering all modern web and mobile applications.

---

---

### Token Introspection

**Description:** An OAuth 2.0 protocol (RFC 7662) where a resource server queries the authorisation server to validate and get metadata about a token at runtime, rather than validating it locally using cached public keys. Useful for opaque tokens or when real-time revocation checking is required.

**Use Cases:** An API gateway calling an enterprise identity provider introspection endpoint to validate a customer's opaque access token in real time when revocation checking is required — for example, following a security incident where tokens must be immediately invalidated. Legacy APIs that receive opaque tokens from an authorisation server and cannot perform local JWT validation.

**Benefits:** Enables real-time token validation and revocation checking, ensuring that invalidated tokens cannot be used to access resources even within the token's remaining validity window. Simplifies resource server logic for opaque tokens — the resource server does not need to manage public key rotation or token parsing.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
