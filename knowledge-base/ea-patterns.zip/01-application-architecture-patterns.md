# Application Architecture Patterns

> Patterns that define how applications are structured, decomposed, and organised at the system and component level. These patterns govern the high-level topology of a software system — how responsibilities are divided, how components relate, and how the system is deployed.

---

### Monolith

**Description:** A single deployable unit containing all application logic, data access, and UI concerns packaged and deployed together. All modules share the same process, memory space, and database.

**Use Cases:** Early-stage products where simplicity and speed of development outweigh scalability needs. Small teams building internal tools, administrative systems, or low-traffic line-of-business applications where deployment complexity must be minimised.

**Benefits:** Simplest deployment model with no distributed system complexity or network overhead between components. Easy to develop, test, and debug locally; a single CI/CD pipeline covers the entire application.

---

---

### Modular Monolith

**Description:** A single deployable unit internally structured into well-defined, loosely coupled modules with explicit boundaries and APIs between them, without the operational overhead of microservices. Modules enforce encapsulation but share the same deployment artifact.

**Use Cases:** Teams that need clear domain separation and the ability to evolve toward microservices without committing to distributed infrastructure prematurely. Suitable for medium-complexity products where inter-module communication latency is unacceptable.

**Benefits:** Combines the simplicity of a single deployment with the code organisation discipline of microservices. Provides a clear migration path to microservices by extracting well-bounded modules into standalone services incrementally.

---

---

### Microservices

**Description:** An architectural style that structures an application as a collection of small, independently deployable services, each owning its own data store and communicating via well-defined APIs or events. Each service aligns to a single business capability or bounded context.

**Use Cases:** Large-scale platforms requiring independent scaling of individual capabilities, such as a compliance verification service that needs more compute than a notification service. Organisations with multiple teams where independent deployment cadences and technology choices per service accelerate delivery.

**Benefits:** Enables independent scaling, deployment, and failure isolation per service, greatly improving overall system resilience. Allows teams to choose the right technology for each service and deploy changes without coordinating a full system release.

---

---

### Micro-Frontend

**Description:** An architectural approach that extends microservices principles to the frontend, decomposing a web UI into independently owned, deployable frontend modules that are composed at runtime or build time. Each team owns the full vertical slice from UI to backend.

**Use Cases:** Large multi-team portal applications where different teams own distinct UI domains — for example, onboarding, account management, and identity verification sections of a banking portal each owned by separate squads. Organisations migrating a legacy monolithic frontend incrementally while shipping new features.

**Benefits:** Enables independent frontend deployments per team, eliminating UI release coordination bottlenecks. Allows gradual technology migration — a new React section can coexist with a legacy Angular section within the same composed shell.

---

---

### Self-Contained Systems (SCS)

**Description:** An architectural style where each system is a fully autonomous web application including its own UI, business logic, and data store, communicating with other systems only asynchronously. SCS avoids shared databases and synchronous inter-system calls entirely.

**Use Cases:** Large enterprise platforms that need strong autonomous team ownership end-to-end, such as separating a customer onboarding system from a loan origination system with no shared dependencies. Scenarios where system unavailability must not cascade to other systems.

**Benefits:** Maximises team autonomy and reduces deployment coupling between systems to near zero. Async-only communication ensures individual system failures do not cascade, improving overall platform resilience.

---

---

### Service-Oriented Architecture (SOA)

**Description:** An architectural paradigm where application functionality is exposed as interoperable, reusable services that communicate via standardised protocols, typically via an Enterprise Service Bus (ESB). Services represent coarse-grained business capabilities shared across the enterprise.

**Use Cases:** Large enterprises integrating heterogeneous systems across business units via a shared services layer, such as a canonical customer service shared between retail banking, mortgages, and insurance applications. Regulated industries requiring centralised policy enforcement at the service bus layer.

**Benefits:** Promotes reuse of shared business capabilities across the enterprise, reducing duplication of core logic. Centralised governance through the ESB enables consistent enforcement of security, logging, and transformation policies across all service consumers.

---

---

### Serverless / Function as a Service (FaaS)

**Description:** An execution model where application logic is packaged as discrete, stateless functions that are invoked on-demand by the platform, with infrastructure provisioning and scaling handled entirely by the cloud provider. Developers focus purely on function logic with no server management.

**Use Cases:** Event-driven processing workloads such as image resizing on upload, webhook handling, or scheduled regulatory report generation. Unpredictable or spiky workloads where paying for always-on infrastructure is wasteful.

**Benefits:** Eliminates infrastructure management overhead entirely, allowing teams to focus on business logic. Provides automatic, near-infinite scaling from zero to peak load with a pay-per-invocation cost model.

---

---

### Plugin Architecture

**Description:** A core application provides stable extension points (APIs or hooks) that allow independently developed plugins or modules to add functionality without modifying the core system. The host application discovers and loads plugins at runtime or startup.

**Use Cases:** Extensible platforms where third parties or separate product teams need to add features without touching core code — such as a banking platform where each product type (current account, savings, mortgage) is a plugin. Development tools, IDEs, and CMS platforms that support community-built extensions.

**Benefits:** Protects the stability of the core platform while enabling rich extensibility without forking the codebase. Allows features to be developed, versioned, and deployed independently of the host application.

---

---

### Layered (N-Tier) Architecture

**Description:** An architecture that organises components into horizontal layers — typically Presentation, Application/Business Logic, and Data Access — where each layer only communicates with the layer directly below it. Dependencies flow strictly downward through the layer stack.

**Use Cases:** Traditional enterprise applications — ERP systems, back-office banking platforms, internal tools — where a clear separation between UI, business rules, and data access is required. Teams with clear role separation between frontend, backend, and database specialists.

**Benefits:** Clear separation of concerns makes each layer independently testable, maintainable, and replaceable. Well-understood by most developers, reducing onboarding time and making responsibility boundaries explicit.

---

---

### Hexagonal Architecture (Ports & Adapters)

**Description:** An architecture that isolates core application logic (the domain) behind a set of ports (interfaces), with adapters implementing those interfaces for specific technologies — REST, databases, message queues. The domain has no dependency on any infrastructure detail.

**Use Cases:** Domain-rich applications where business logic must be testable in complete isolation from frameworks, databases, and external APIs. Microservices requiring multiple delivery mechanisms — REST API today, event consumer tomorrow — without changing the domain model.

**Benefits:** Core business logic is entirely framework and infrastructure agnostic, making it trivially unit-testable without mocking frameworks or standing up databases. Technology choices for adapters can be changed or upgraded without touching the domain.

---

---

### Onion Architecture

**Description:** A layered architecture variant where the domain model sits at the centre, surrounded by concentric rings of domain services, application services, and infrastructure, with dependencies always pointing inward toward the domain. Nothing in an inner ring knows about an outer ring.

**Use Cases:** Complex domain-driven applications where protecting the purity of the domain model from infrastructure concerns is paramount. Financial systems, insurance underwriting platforms, or healthcare applications with rich, rule-heavy domain logic.

**Benefits:** The domain model is completely isolated from infrastructure and framework concerns, making it portable and independently testable. Enforces the Dependency Inversion Principle architecturally, preventing infrastructure leakage into business logic.

---

---

### Clean Architecture

**Description:** An architecture popularised by Robert C. Martin that organises code into concentric circles — Entities, Use Cases, Interface Adapters, and Frameworks — with the Dependency Rule: source code dependencies must always point inward. Use cases and entities know nothing of databases, UIs, or frameworks.

**Use Cases:** Long-lived enterprise applications where the cost of coupling business logic to a specific framework or database is unacceptable. Teams adopting TDD as a core practice who need all use cases to be testable without any infrastructure dependencies.

**Benefits:** Use cases and entities represent stable, framework-free business rules that survive technology changes entirely. Produces highly testable code where every use case can be validated with pure unit tests, dramatically reducing test execution time.

---

---

### Domain-Driven Design (DDD)

**Description:** A software development approach that centres the design of a system on a rich domain model that reflects the business, with ubiquitous language shared between developers and domain experts. DDD defines strategic patterns (Bounded Context, Context Map) and tactical patterns (Aggregate, Entity, Value Object, Domain Event).

**Use Cases:** Complex domains with rich business rules — banking, insurance, healthcare, logistics — where misalignment between the code model and the business model causes persistent defects and rework. Large engineering organisations requiring clear team and service boundaries aligned to business capabilities.

**Benefits:** Aligns the software model directly to the business domain, dramatically reducing the translation layer between business requirements and code. Provides clear bounded contexts that become natural microservice or module boundaries, reducing coupling and improving team autonomy.

---

---

### Strangler Fig

**Description:** A migration pattern where a new system is built incrementally alongside a legacy system, with traffic gradually redirected from the old system to the new one feature by feature, until the legacy system is fully replaced and can be decommissioned. Named after the strangler fig tree that grows around a host tree until it replaces it.

**Use Cases:** Legacy modernisation programmes where a big-bang rewrite is too risky — replacing a monolithic banking legacy core system with a microservices platform while keeping the bank operational. Migrating from an on-premises monolith to a cloud-native architecture without service disruption.

**Benefits:** Eliminates the extreme risk of big-bang rewrites by allowing the new system to be proven incrementally in production before the legacy system is decommissioned. Enables rollback at any stage by reverting traffic routing, providing a safety net not available with full replacement approaches.

---

---

### Anti-Corruption Layer (ACL)

**Description:** A translation layer that sits between two systems with different domain models, translating concepts from one model into the other without allowing the upstream model's concepts to corrupt the downstream model. The ACL acts as a clean boundary between bounded contexts.

**Use Cases:** Integrating a modern microservices platform with a legacy system whose data model and naming conventions would corrupt the clean domain model of the new system. Consuming a third-party API (e.g., a third-party verification provider identity verification) whose response model must be translated into internal domain concepts.

**Benefits:** Protects the integrity of the new system's domain model from being contaminated by legacy or external concepts, preserving clean architecture boundaries. Isolates all translation logic in one place, making it easy to adapt when the upstream system changes without modifying the core domain.

---

---

### Backend for Frontend (BFF)

**Description:** A pattern where a dedicated backend service is created for each specific frontend client type — web browser, mobile app, third-party API consumer — tailored to that client's exact data and interaction needs. The BFF aggregates calls to multiple downstream services and shapes the response for its specific client.

**Use Cases:** Banking portals where the customer mobile app needs a different data shape and API contract than the staff desktop portal or a regulatory reporting API consumer. Avoiding the over-fetching and under-fetching problems of a single generic API shared across all client types.

**Benefits:** Each client gets an API perfectly shaped for its needs without compromise, reducing client-side data transformation logic and network chattiness. Changes to one client's API contract do not affect other clients, enabling independent evolution of the mobile and web experiences.

---

---

### Sidecar

**Description:** A design pattern where a secondary container or process is deployed alongside the main application container, providing cross-cutting concerns such as logging, service mesh proxy, secret injection, or configuration without modifying the main application code. Both containers share the same network and storage namespace.

**Use Cases:** Injecting a sidecar proxy or a service mesh proxy sidecars for service mesh capabilities (mTLS, tracing, load balancing) into every microservice pod without changing the microservice code. Using a sidecar to handle secret rotation from a secrets management service, making secrets available to the main container via a shared volume.

**Benefits:** Separates cross-cutting infrastructure concerns from application business logic entirely, allowing each to evolve independently. Enables uniformly applying capabilities like observability, security, and configuration management across all services without requiring application code changes.

---

---

### Ambassador

**Description:** A variant of the sidecar pattern where a helper process acts as an out-of-process proxy for a remote service, handling concerns such as retry logic, circuit breaking, timeout management, and connection pooling on behalf of the main application. The main application communicates only with the local ambassador.

**Use Cases:** Legacy applications that cannot be modified to implement resilience patterns natively — the ambassador handles retries and circuit breakers externally. Abstracting away the details of connecting to a remote service (e.g., a database with complex failover routing) behind a simple local endpoint.

**Benefits:** Adds resilience and observability capabilities to applications that cannot or should not be modified. Centralises connection management logic in the ambassador, avoiding duplication of retry and circuit-breaking code across multiple application components.

---

---

### Shared Kernel

**Description:** A DDD pattern where two bounded contexts deliberately share a small, carefully chosen subset of the domain model — a shared library or package — maintained collaboratively by both teams. Changes to the shared kernel require agreement from both teams.

**Use Cases:** Two microservices that share a canonical set of domain events or value objects — such as a CustomerId type or a shared Money value object — where duplication would cause costly translation errors. Platform teams providing a shared SDK of common domain types used across multiple bounded contexts.

**Benefits:** Eliminates costly and error-prone translation of identical concepts between bounded contexts that must communicate frequently. Provides a single source of truth for shared domain concepts, ensuring consistency in types, validation rules, and semantics.

---

---

### Open Host Service

**Description:** A DDD integration pattern where a subsystem provides a well-defined, versioned, publicly documented API (the open host) as a formal published language for all external consumers. Consumers adapt to the published language without the host adapting to each consumer's model.

**Use Cases:** Platform teams exposing a shared capability — such as a Customer Profile API or a identity verification API — to multiple internal consuming teams or external third parties. Any service that needs to scale its number of consumers without customising its interface for each.

**Benefits:** Decouples the service from individual consumer needs through a stable, versioned published language, allowing the number of consumers to grow without interface proliferation. Makes integration contracts explicit and documented, reducing integration defects and consumer onboarding friction.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
