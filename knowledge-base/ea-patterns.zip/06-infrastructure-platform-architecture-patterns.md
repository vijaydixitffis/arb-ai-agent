# Infrastructure & Platform Architecture Patterns

> Patterns that govern the provisioning, deployment, topology, scaling, and resilience of the infrastructure and platform layer. These patterns cover cloud deployment models, networking topologies, container orchestration, and operational strategies.

---

### Infrastructure as Code (IaC)

**Description:** The practice of managing and provisioning infrastructure — servers, networks, databases, load balancers — through machine-readable declarative configuration files rather than manual processes or interactive configuration tools. Infrastructure state is version-controlled, reviewable, and reproducible.

**Use Cases:** Managing all the platform cloud resources — the container platform cluster, the relational database, a NoSQL document store, the API gateway, a secrets vault, virtual networks — via an IaC tool configurations stored in Git, enabling any environment to be created or destroyed reproducibly in minutes. Enforcing compliance standards as code by running policy checks (checkov, tfsec) against an IaC tool plans before applying.

**Benefits:** Ensures environments are reproducible, consistent, and free of configuration drift caused by manual changes. Infrastructure changes are subject to code review, version history, and automated testing, applying the same engineering discipline to infrastructure as to application code.

---

---

### Immutable Infrastructure

**Description:** An infrastructure paradigm where servers and containers are never modified in place after deployment — instead, updated versions are built as new artifacts and deployed to replace the old ones. If a change is needed, a new image is built, deployed, and the old instance is terminated.

**Use Cases:** The container platform pod deployments where every new microservice version is built as a new container image tagged with a unique Git SHA, deployed by a GitOps controller to replace old pods in a rolling update, with old pods deleted rather than modified. Never SSH-ing into a running container to make a configuration change.

**Benefits:** Eliminates configuration drift and the "works on my machine" problem caused by incremental in-place changes — every deployed instance is identical to the build artifact. Simplifies rollback to simply re-deploying the previous image version, since the old image is never modified.

---

---

### GitOps

**Description:** An operational framework for Kubernetes and cloud infrastructure that uses Git as the single source of truth for both application and infrastructure state, with automated reconciliation controllers ensuring the live system matches the state declared in Git. All changes are made via Git commits and pull requests.

**Use Cases:** A GitOps controller continuously reconciling the platform the container platform cluster state against a package deployment manifest manifests stored in a GitOps repository, automatically applying any new service version merged to the main branch without manual kubectl apply commands. Managing an IaC tool state changes via GitOps pipelines that plan on PR and apply on merge.

**Benefits:** Provides a complete, auditable history of every infrastructure and deployment change in Git, with pull request reviews enforcing change approval workflows. Enables automatic drift detection and remediation — if a manual change is made to the cluster, the GitOps controller reverts it to the declared state.

---

---

### Blue-Green Deployment

**Description:** A deployment strategy that maintains two identical production environments (Blue and Green) where one is live (Blue) and one is idle (Green). New versions are deployed to the idle environment, tested, and then traffic is switched from Blue to Green. Rollback is instant by switching traffic back.

**Use Cases:** Deploying a new version of the platform a customer-facing portal to the Green cloud Static Web Apps slot, running smoke tests against it, then switching a global load balancer routing from Blue to Green — enabling instant rollback by reverting the Front Door rule if issues emerge. Zero-downtime deployments for the application backend where a failover to the old version must be achievable in seconds.

**Benefits:** Provides instant rollback capability with zero downtime — if the new version has issues, traffic is switched back to the old version in seconds. The idle environment serves as a pre-production validation environment that is identical to production, enabling high-confidence testing before traffic switch.

---

---

### Canary Deployment

**Description:** A progressive deployment strategy where a new version is initially deployed to a small subset of users or servers (the canary), with monitoring and automated analysis determining whether the canary is healthy before gradually increasing traffic to the new version until it reaches 100%.

**Use Cases:** Rolling out a new version of the compliance verification service to 5% of onboarding requests, monitoring error rates and latency in real time, and automatically promoting to 100% if metrics remain healthy over 30 minutes — aborting and rolling back if any SLO is breached. Validating a new ML risk scoring model on a fraction of real customer onboardings before full deployment.

**Benefits:** Detects regressions in production with real traffic at minimal blast radius — only a small percentage of users are affected by a bad deployment before it is detected and rolled back. Enables gradual, data-driven deployment decisions based on real production metrics rather than pre-production test results.

---

---

### Feature Flags / Feature Toggles

**Description:** A software development technique that allows features in production code to be enabled or disabled at runtime via configuration — without deploying new code — enabling trunk-based development, dark launches, A/B testing, and instant feature rollback.

**Use Cases:** Deploying the Welsh language support feature in the platform a customer-facing portal behind a feature flag, enabling it for internal testers and Welsh-speaking users in the beta group before gradually rolling it out to all UK customers. Dark-launching the new identity verification ML risk scoring model to process all requests in shadow mode without affecting the live identity verification decision, comparing outputs before enabling it.

**Benefits:** Decouples code deployment from feature release, enabling frequent deployments of incomplete features without exposing them to customers, supporting true trunk-based development. Provides an instant kill switch for any feature exhibiting production issues — disable the flag in seconds without a rollback deployment.

---

---

### Hub-Spoke Network Topology

**Description:** A network architecture where multiple spoke virtual networks connect to a central hub virtual network, with all inter-spoke and internet-bound traffic transiting through the hub. Shared network services — firewalls, DNS, VPN gateways, Bastion — are hosted in the hub and shared by all spokes.

**Use Cases:** The platform deploying its the container platform workload in a dedicated the platform spoke a virtual network connected to the organisation hub a virtual network, sharing the hub's cloud Firewall for egress control, cloud Bastion for secure admin access, and the DNS server for private endpoint name resolution. Isolating dev, SIT, UAT, and prod workloads in separate spoke virtual networks connected to the same hub.

**Benefits:** Centralises shared network services — firewall, DNS, VPN, Bastion — in one place, eliminating duplication across each workload's a virtual network and reducing cost and management overhead. Provides strong network isolation between workload spokes while allowing controlled, monitored communication through the hub.

---

---

### Zero Trust Network Architecture (ZTNA)

**Description:** A security model that eliminates implicit trust based on network location — no traffic is trusted by default regardless of whether it originates inside or outside the corporate network. Every access request must be explicitly authenticated, authorised, and continuously validated before granting access to any resource.

**Use Cases:** Enforcing mTLS between all the container platform's pods regardless of whether they are on the same node or a virtual network, combined with an enterprise identity provider token validation at every API call — no service trusts another based on network adjacency alone. Replacing VPN-based remote access with identity-aware conditional access policies for staff accessing an internal staff portal.

**Benefits:** Eliminates the implicit trust of the traditional network perimeter model, dramatically reducing the blast radius of a compromised internal host — a compromised pod cannot laterally move to other services without valid credentials and certificates. Aligns security controls to where they matter — at the identity and workload level — rather than the increasingly obsolete network perimeter.

---

---

### Service Mesh

**Description:** A dedicated infrastructure layer for handling service-to-service communication within a microservices architecture, providing capabilities including mTLS, load balancing, circuit breaking, retries, observability, and traffic management as a transparent sidecar without application code changes.

**Use Cases:** Deploying a service mesh on the platform the container platform cluster to automatically enforce mTLS between all 8 microservices, collect distributed traces, and implement fine-grained traffic policies (canary routing, traffic mirroring) without modifying any microservice code. Implementing zero-trust service identity for all inter-pod communication using a workload identity standard certificates issued by a service mesh.

**Benefits:** Provides uniform, consistently enforced mTLS, observability, and traffic management across all services without requiring each service to implement these capabilities, eliminating redundant code across 8+ microservices. The mesh makes all inter-service communication visible and measurable, dramatically improving debugging and performance analysis.

---

---

### Cell-Based Architecture

**Description:** An architecture that divides a large system into independent, identically structured cells — each cell being a complete, self-sufficient instance of the service with its own data, compute, and dependencies — to limit the blast radius of failures and enable massive horizontal scale.

**Use Cases:** Partitioning the application backend into regional cells — one cell per geographic region — each serving a subset of customers, so that a failure in the secondary cloud region cell affects only that cell's customers without impacting others. Large-scale SaaS platforms where a single tenant's abnormal load must be isolated from affecting other tenants.

**Benefits:** Strictly limits the blast radius of any failure to a single cell, providing fault isolation that cluster-level redundancy cannot achieve. Enables near-linear horizontal scaling by adding new cells without modifying the architecture of existing cells.

---

---

### Multi-Region Active-Active

**Description:** A deployment topology where the application runs simultaneously in multiple geographic regions with all instances actively serving traffic, using global load balancing to route requests to the nearest or healthiest region. Data is synchronised across regions with conflict resolution strategies.

**Use Cases:** A globally distributed banking platform where a customer-facing portal traffic is served from the nearest region — UK customers from the primary cloud region, EU customers from West Europe — with all regions active simultaneously. High-availability configurations where any single region failure results in zero downtime as other regions absorb traffic immediately.

**Benefits:** Eliminates region-level single points of failure with zero-RPO and near-zero RTO for region failures, as other active regions immediately absorb traffic without a failover delay. Reduces latency for geographically distributed users by routing them to the nearest active region.

---

---

### Multi-Region Active-Passive

**Description:** A deployment topology where the application runs in a primary region actively serving all traffic, with a secondary region running in warm or hot standby, receiving replicated data but not serving traffic until a failover event occurs. Recovery involves promoting the passive region to active.

**Use Cases:** The platform deployed active in the primary cloud region with a warm standby in the secondary cloud region, activated only during a the primary cloud region region failure — RPO < 15 minutes, RTO < 4 hours. Regulated banking platforms where the cost of active-active multi-region is not justified but RPO/RTO targets must be met.

**Benefits:** Provides disaster recovery with defined RPO and RTO targets at significantly lower cost than active-active, as the passive region runs at reduced capacity. Simpler data consistency model than active-active — the primary region is always the write master, eliminating multi-region write conflict complexity.

---

---

### Availability Zone Spread

**Description:** A deployment pattern that distributes application instances, database replicas, and infrastructure components across multiple physically separate Availability Zones within a single cloud region, providing high availability against the failure of any single zone's power, cooling, or networking.

**Use Cases:** The platform the container platform cluster spreading node pools across the primary cloud region AZ1, AZ2, and AZ3 so that a data centre fire in AZ1 does not take down the cluster. a managed relational database Business Critical deploying 3 synchronous replicas across 3 AZs for automatic failover within seconds if one zone is lost.

**Benefits:** Provides high availability against zone-level failures with typically sub-60-second automated recovery, meeting Four Nines (99.99%) availability targets without the complexity of multi-region deployment. No data centre dependency for single-site high availability within a cloud region.

---

---

### Warm Standby

**Description:** A disaster recovery configuration where the standby environment is partially provisioned and running — data is replicated to it and minimal infrastructure is kept warm — allowing it to be scaled to full production capacity and promoted to active within minutes to hours of a DR event.

**Use Cases:** The platform the secondary cloud region DR environment running 3 the container platform nodes with data replicated from the primary cloud region via the relational database geo-replication and a NoSQL document store auto-failover, able to scale to 6+ nodes and promote to active within the 4-hour RTO target. Cost-effective DR for banking platforms that need sub-4-hour RTO without the expense of active-active.

**Benefits:** Provides a balance between cost and recovery time — more expensive than cold standby but significantly faster to activate, meeting RTO targets measured in hours rather than days. Data replication to the standby region ensures RPO targets can be met without complete data reconstruction.

---

---

### Chaos Engineering

**Description:** The practice of deliberately injecting failures — pod crashes, network latency, dependency outages, disk failures — into production or production-like environments to discover weaknesses in the system's resilience before those weaknesses cause unplanned outages.

**Use Cases:** Running Netflix Chaos Monkey equivalents on the platform the container platform cluster to randomly terminate pods and verify that the container platform auto-restarts them and circuit breakers prevent cascade failures. Simulating a third-party verification API unavailability in a staging environment to verify that the identity verification circuit breaker correctly routes to manual review.

**Benefits:** Discovers resilience weaknesses and missing circuit breakers before they cause production incidents, shifting failure discovery from unplanned outages to controlled experiments. Builds confidence in the system's resilience claims by empirically validating them through deliberate failure injection rather than relying on architectural assertions.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
