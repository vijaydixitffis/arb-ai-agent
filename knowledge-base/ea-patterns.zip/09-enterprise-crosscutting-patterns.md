# Enterprise & Cross-Cutting Architecture Patterns

> Patterns that operate at the enterprise architecture level, spanning multiple domains and concerns. These patterns address domain boundaries, platform thinking, system composability, and organisation-wide architectural approaches.

---

### Bounded Context

**Description:** A DDD strategic pattern that defines the explicit boundary within which a particular domain model applies, with a ubiquitous language that is consistent and unambiguous within that context but may use the same terms with different meanings in different contexts. Each bounded context has a clear owner.

**Use Cases:** The platform defining five bounded contexts — Identity (identity verification, onboarding), Customer Profile (canonical entity), Product (accounts, eligibility), Case Management (operational tasks), and CRM (relationship management) — each with its own model, team, and service. The term "Customer" means different things in the CRM context (a relationship) vs the Identity context (an identity being verified).

**Benefits:** Prevents model confusion caused by a single, monolithic enterprise model that tries to mean all things to all systems, which inevitably becomes incorrect for all of them. Enables team autonomy — each bounded context team can evolve their model independently without negotiating with every other team.

---

---

### Context Map

**Description:** A DDD strategic pattern that documents the relationships between bounded contexts in a system, including the type of integration relationship (Customer-Supplier, Conformist, Anti-Corruption Layer, Shared Kernel, Open Host Service) and the direction of dependency and influence.

**Use Cases:** Documenting that the platform Identity context is an Open Host Service that the CRM context conforms to via an Anti-Corruption Layer translator, while an analytics platform is a Conformist that adapts to the application backend's published event schema without any translation. Identifying which bounded context owns the customer golden record.

**Benefits:** Makes inter-context integration relationships and dependencies explicit, enabling architectural decisions about integration patterns to be made consciously rather than ad hoc. Reveals power imbalances between contexts (upstream/downstream) that affect team collaboration and integration governance.

---

---

### Platform Architecture

**Description:** An architectural approach that builds internal developer platforms providing self-service capabilities — infrastructure provisioning, CI/CD pipelines, observability, security controls — that product engineering teams consume as a service, rather than each team managing its own infrastructure.

**Use Cases:** The organisation's Platform Engineering team building an internal developer platform (IDP) that the platform, IBP, and Payments teams all consume — providing standardised the container platform clusters, an IaC tool modules, a CI/CD platform pipeline templates, and monitoring dashboards via a self-service portal. Enabling product teams to deploy new services in hours rather than weeks.

**Benefits:** Dramatically reduces the cognitive load and infrastructure expertise required by product teams, allowing them to focus on business logic rather than infrastructure plumbing. Enforces consistent, secure, compliant infrastructure patterns across all product teams through golden-path templates.

---

---

### Composable Architecture

**Description:** An architecture approach that builds capabilities as independent, reusable, replaceable components that can be assembled and reassembled into different solutions, emphasising modularity and loose coupling. Components expose well-defined interfaces and make no assumptions about how they are composed.

**Use Cases:** Building composable onboarding journey steps — identity verification, document upload, a verification check, account opening, notification — as independent components that can be reconfigured to produce different onboarding journeys for different customer segments without rebuilding an onboarding service. Composing regulatory reporting capabilities from reusable data pipeline components.

**Benefits:** Enables rapid assembly of new capabilities from existing components, dramatically reducing time-to-market for new product variants or regulatory changes. Reduces technical debt by ensuring each component is built once and reused rather than rebuilding similar capabilities for each new use case.

---

---

### Event-Driven Architecture (EDA)

**Description:** A broad architectural paradigm where components communicate by producing and consuming events asynchronously, with the event broker as the central nervous system of the platform. Producers emit events when something noteworthy happens; consumers react to those events independently and asynchronously.

**Use Cases:** The platform as an event-driven system where a DomainEntityCreated event simultaneously triggers CRM record creation, welcome notification, analytics pipeline update, and audit log — all consumers reacting independently without any orchestration. Fraud detection platforms processing millions of transaction events per second with real-time alerting.

**Benefits:** Provides near-infinite decoupling between producers and consumers — producers never know who consumes their events, enabling new capabilities to be added by adding new consumers without modifying existing systems. The event log provides a natural, replayable audit trail of all significant business facts.

---

---

### Microkernel

**Description:** An architectural style — also called the Plugin Architecture in application contexts — where a minimal core system (the microkernel) provides only the most fundamental services, with all additional capabilities implemented as plugins that extend the core. The core is stable; functionality grows through plugins.

**Use Cases:** A banking product platform where the microkernel provides the core account management and transaction capabilities, with each product type (current account, savings, mortgage, credit card) implemented as a separate plugin extending the core. IDEs, operating systems, and extensible CMS platforms built around a stable, minimal core.

**Benefits:** Keeps the core system minimal, stable, and highly maintainable while enabling rich extensibility without modifying core code. New capabilities can be developed, tested, and deployed as plugins independently of the core release cycle.

---

---

### Pipe and Filter

**Description:** An architectural style that processes a data stream through a sequence of processing components (filters) connected by channels (pipes), where each filter transforms its input and passes the result to the next filter in the pipeline. Filters are independently replaceable and reorderable.

**Use Cases:** Identity verification document processing pipeline: Document Upload → Virus Scan Filter → OCR Text Extraction Filter → Identity Extraction Filter → Validation Filter → Risk Score Filter → Decision Filter — each step independently testable and replaceable. ETL data processing pipelines where each stage transforms the data before passing it to the next.

**Benefits:** Highly composable and testable — each filter can be developed, tested, and replaced independently without affecting other filters in the pipeline. Processing stages can be parallelised or distributed across different execution environments by adding parallelism between pipe stages.

---

---

### Reactive Architecture

**Description:** An architectural approach guided by the Reactive Manifesto, designing systems to be Responsive (fast, consistent response times), Resilient (staying responsive under failure), Elastic (staying responsive under varying load), and Message-Driven (async, non-blocking communication between components).

**Use Cases:** The application backend services using a reactive web framework (a reactive programming library) for non-blocking I/O, processing a verification check results as reactive streams that do not block threads while waiting for a third-party verification API responses — enabling high throughput with a small thread pool. Real-time fraud scoring platforms processing hundreds of thousands of transaction events per second reactively.

**Benefits:** Non-blocking I/O enables much higher throughput per CPU thread compared to traditional blocking request-response models, reducing infrastructure cost at scale. Backpressure mechanisms in reactive streams prevent fast producers from overwhelming slow consumers, providing natural flow control.

---

---

### FinOps Patterns

**Description:** A set of organisational and technical practices that bring financial accountability to the variable spend of cloud infrastructure, combining financial management, business value optimisation, and engineering practices to maximise the value delivered per pound of cloud spend.

**Use Cases:** The platform implementing cloud cost allocation tags on all resources for chargeback to business units, using cloud Cost Management to set budgets and alerts per environment, auto-pausing the Synapse dedicated SQL pool during off-hours to eliminate idle spend, and using cloud Reserved Instances for predictable the container platform node pool workloads. Monthly FinOps review between Platform Engineering and Finance to analyse the platform cloud spend by service.

**Benefits:** Creates financial accountability for cloud costs at the team level, aligning spending decisions with business value and eliminating wasteful idle resource spend. Provides the data needed to make evidence-based decisions about reserved capacity versus on-demand purchasing, often reducing cloud spend by 30–40%.

---

*End of Enterprise Architecture Patterns Reference*

---

> **Document Information**
> - **Domain Coverage:** Application, Software Design, Integration, API, Data, Infrastructure & Platform, Security, DevSecOps & Engineering, Enterprise & Cross-Cutting
> - **Total Patterns:** 175+
> - **Format:** Name → Description → Use Cases → Benefits
> - **Version:** 1.0 | April 2026

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
