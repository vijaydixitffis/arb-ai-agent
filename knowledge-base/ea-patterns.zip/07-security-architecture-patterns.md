# Security Architecture Patterns

> Patterns that establish the security posture of a system — covering identity, authorisation, key management, data protection, network security, and auditability. These patterns are applicable across all architecture layers.

---

### Zero Trust Architecture

**Description:** A security framework based on the principle of "never trust, always verify" — every user, device, service, and network flow is treated as untrusted regardless of location, requiring continuous authentication, authorisation, and validation. Access is granted on a least-privilege, need-to-know basis per request.

**Use Cases:** Enforcing an enterprise identity provider authentication for every API call regardless of internal or external origin, combined with mTLS between all microservices, private endpoints for all PaaS, and an enterprise identity provider PIM for any privileged access. Replacing VPN-based implicit corporate network trust with identity-aware conditional access.

**Benefits:** Eliminates the catastrophic blast radius of a perimeter breach — a compromised internal host cannot laterally access other services without valid, audited credentials. Provides continuous, measurable assurance of access control across all resources rather than a binary inside/outside network trust model.

---

---

### Defence in Depth

**Description:** A layered security strategy that applies multiple independent security controls at each layer — network, host, application, data — so that the failure of any single control does not result in a full system compromise. Each layer provides an independent barrier to an attacker.

**Use Cases:** The platform applying security at five independent layers: a global load balancer WAF (L1), the API gateway policy and rate limiting (L2), an enterprise identity provider JWT validation (L3), the application security framework RBAC at service layer (L4), the relational database column-level masking and write-once-read-many (WORM) audit log (L5). An attacker bypassing one layer still faces four more.

**Benefits:** Significantly raises the cost and complexity of a successful attack — multiple independent controls must all be bypassed rather than a single perimeter. Provides a safety net where a misconfigured or compromised layer is compensated for by remaining layers, maintaining overall security posture.

---

---

### Least Privilege

**Description:** A security principle that grants every user, service account, and system component only the minimum permissions required to perform its specific function, and nothing more. Access is scoped to the exact resources, operations, and time window needed.

**Use Cases:** The STAFF_AGENT an enterprise identity provider role granted read access to customer PII and the ability to create cases, but explicitly denied identity verification override permissions reserved for the COMPLIANCE role. the container platform pod Managed Identities granted only the specific a secrets vault secret read permissions needed, not full a secrets vault administrator access.

**Benefits:** Limits the damage of a compromised account or service to only the resources it was authorised to access, dramatically reducing breach blast radius. Enforces explicit, auditable authorisation decisions for every resource access, making unexpected access patterns detectable.

---

---

### Privileged Access Management (PAM)

**Description:** A security discipline that controls, monitors, and audits access to privileged accounts and administrative functions, using technologies such as credential vaulting, just-in-time access provisioning, and session recording to minimise the risk of privileged account abuse.

**Use Cases:** The platform using an enterprise identity provider Privileged Identity Management (PIM) to require identity verification analysts to explicitly activate their KYC_ANALYST role with approval and justification for a maximum 4-hour window, with all privileged actions recorded in an immutable audit log. Vaulting database administrator credentials in a secrets management service rather than sharing them among DBAs.

**Benefits:** Eliminates the risk of standing privileged access — accounts with permanent admin rights that represent a high-value, always-available target for attackers. Provides a complete audit trail of every privileged action including who approved it, when it was used, and what was done.

---

---

### RBAC (Role-Based Access Control)

**Description:** An access control model that assigns permissions to named roles rather than to individual users, with users granted access by being assigned to the appropriate roles. Permissions are managed at the role level, simplifying administration as users come and go.

**Use Cases:** The platform defining 7 roles (CUSTOMER, STAFF_AGENT, STAFF_MANAGER, COMPLIANCE, KYC_ANALYST, EA_ADMIN, READONLY_REPORT) with a precise permissions matrix enforced at both the API gateway (JWT scope validation) and the application security framework (@PreAuthorize annotation) layers. cloud RBAC scoping each service's Managed Identity to only the specific resource group and operation type it requires.

**Benefits:** Simplifies access management administration — when a new staff member joins, they are assigned the correct role rather than requiring individual permission grants. Ensures consistent, auditable access control across the organisation with clear separation of duties enforced through role boundaries.

---

---

### Envelope Encryption

**Description:** A key management pattern where data is encrypted with a data encryption key (DEK), and the DEK itself is encrypted with a key encryption key (KEK) stored in a hardware security module (HSM). Only the encrypted DEK is stored alongside the data; the KEK never leaves the HSM.

**Use Cases:** The platform encrypting all RESTRICTED customer PII in a managed relational database and a NoSQL document store with data encryption keys, with those DEKs encrypted by customer-managed KEKs stored in a secrets management service Managed HSM — implementing Transparent Data Encryption with customer-managed keys. identity verification document encryption in object storage with per-document DEKs wrapped by a master KEK.

**Benefits:** Enables key rotation at the KEK level without re-encrypting all data — only the DEK re-encryption is required. Allows the customer to retain control of the root encryption key in an HSM while allowing the cloud provider to manage the operational encryption of data.

---

---

### Immutable Audit Log

**Description:** A security and compliance pattern that records all significant system and user actions in a write-once, tamper-evident log store, ensuring that the audit trail cannot be modified, deleted, or backdated. Typically implemented using write-once-read-many (WORM) (Write Once, Read Many) storage or an append-only cryptographic log.

**Use Cases:** The platform an audit service writing all customer actions, agent overrides, identity verification decisions, and data access events to table storage with write-once-read-many (WORM) immutability policy enforced — satisfying the financial regulator SYSC 9.1R audit trail requirements and providing tamper-proof evidence for regulatory examinations. Immutable logging of all identity verification overrides with agent identity, timestamp, and rationale for the financial regulator audit purposes.

**Benefits:** Provides legally defensible, tamper-proof evidence of all system actions that cannot be manipulated even by privileged administrators, satisfying the strictest regulatory non-repudiation requirements. Creates a reliable forensic record for incident investigation, enabling complete reconstruction of the sequence of events leading to a security or compliance incident.

---

---

### Supply Chain Security (a supply chain security framework)

**Description:** A security framework (Supply-chain Levels for Software Artifacts) that provides a graduated set of requirements for securing the software build and delivery pipeline, ensuring that artifacts have not been tampered with between source code and production deployment.

**Use Cases:** The platform CI/CD pipeline implementing a supply chain security framework Level 3 by signing all container images with an image signing tool using a Sigstore transparency log, with a GitOps controller verifying signatures before deploying to the container platform — preventing a compromised registry or pipeline from deploying malicious images. Generating signed SBOMs attached to every container image to enable downstream vulnerability scanning and compliance auditing.

**Benefits:** Prevents supply chain attacks — where an attacker compromises a build pipeline or dependency to inject malicious code — by creating a verifiable, cryptographically signed provenance trail from source to deployment. Provides regulatory and operational confidence in the integrity of every deployed artifact.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
