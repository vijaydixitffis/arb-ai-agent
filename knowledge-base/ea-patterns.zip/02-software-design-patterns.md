# Software Design Patterns

> Patterns that govern the internal structure and behaviour of software components — how objects, aggregates, and services collaborate within a bounded context. These patterns operate at the code and component level, providing reusable solutions to recurring design problems.

---

### CQRS (Command Query Responsibility Segregation)

**Description:** An architectural pattern that separates the write model (Commands that change state) from the read model (Queries that return data), allowing each to be optimised, scaled, and evolved independently. Commands mutate state; queries return projections of state.

**Use Cases:** High-read, low-write systems — such as customer dashboards or regulatory reporting — where the read model needs a denormalised projection for fast queries while the write model enforces strict business invariants. Systems using Event Sourcing where the write model is an event store and the read model is a materialised view.

**Benefits:** Read and write sides can be scaled independently, enabling each to use the most appropriate storage technology. Eliminates the tension between normalised write models and denormalised read models, optimising each without compromise.

---

---

### Event Sourcing

**Description:** A persistence pattern where the state of an entity is not stored directly but derived from a sequence of immutable domain events stored in an append-only event store. The current state is obtained by replaying all events from the beginning or from a snapshot.

**Use Cases:** Audit-critical systems — banking transactions, identity verification decisions, compliance logs — where a complete, tamper-proof history of every state change is a regulatory requirement. Systems requiring temporal queries such as "what was the customer's risk rating on a specific date."

**Benefits:** Provides a complete, immutable audit trail of every state change with no additional logging infrastructure required. Enables powerful capabilities including event replay for debugging, temporal state queries, and rebuilding read model projections by replaying the event history.

---

---

### Saga (Choreography / Orchestration)

**Description:** A pattern for managing distributed transactions across multiple microservices without a two-phase commit, using a sequence of local transactions where each step publishes an event or command to trigger the next step, with compensating transactions for rollback on failure. Choreography uses events; Orchestration uses a central coordinator.

**Use Cases:** Long-running business processes spanning multiple services — such as a banking onboarding flow that must create a customer, run identity verification, open an account, and notify CRM — where a single distributed transaction is not feasible. Any multi-step workflow where partial failure must trigger a defined rollback sequence.

**Benefits:** Enables data consistency across microservices without the locking and coupling of distributed transactions (XA/2PC). Compensating transactions make failure recovery explicit and auditable, ensuring the system reaches a consistent state even when individual steps fail.

---

---

### Outbox Pattern

**Description:** A reliability pattern that guarantees at-least-once event publishing by writing domain events to an outbox table in the same local database transaction as the state change, then having a separate process publish events from the outbox to the message broker. Eliminates the dual-write problem between a database and a message broker.

**Use Cases:** Microservices that must reliably publish domain events to a message bus (e.g., a managed message broker) as part of a business transaction — such as publishing a DomainEntityCreated event only if the customer record is successfully persisted. Any system where losing an event due to a broker outage is unacceptable.

**Benefits:** Eliminates the risk of publishing an event without the state change completing, or committing the state change without publishing the event. Guarantees event delivery even if the message broker is temporarily unavailable, using the database as a durable buffer.

---

---

### Repository Pattern

**Description:** A design pattern that abstracts the data access layer behind a collection-like interface, allowing the domain model to work with aggregates and entities without knowing the underlying persistence mechanism. The repository provides methods like findById, save, and delete.

**Use Cases:** Domain-driven applications using Clean or Hexagonal Architecture where the domain model must be independent of persistence technology. Enabling easy swapping of persistence implementations during testing (in-memory repository) or when migrating from one database to another.

**Benefits:** Decouples domain logic from persistence concerns entirely, making domain objects and use cases testable without a database. Centralises all data access logic in one place, making it easy to add caching, logging, or optimistic locking consistently across all persistence operations.

---

---

### Unit of Work

**Description:** A pattern that tracks all objects changed during a business transaction and coordinates the writing out of changes to the database as a single atomic unit, ensuring that all changes in a business operation either commit together or roll back together. Typically implemented alongside the Repository pattern.

**Use Cases:** Complex business transactions that modify multiple aggregate roots — such as an onboarding saga step that creates a customer record, a verification check record, and an onboarding application record — that must all commit atomically or roll back together. ORM frameworks (an ORM framework, Entity Framework) commonly implement this pattern.

**Benefits:** Ensures data consistency across multiple domain objects within a single business transaction without manually managing transactions in every service method. Reduces database round-trips by batching all changes in a transaction into a single commit.

---

---

### Domain Model

**Description:** A rich object-oriented model of the business domain that encapsulates both data and behaviour, with entities that enforce business rules and invariants directly on themselves. The domain model reflects the ubiquitous language of the domain and acts as the single source of business truth.

**Use Cases:** Complex, rule-heavy business domains such as banking, insurance underwriting, or healthcare where business rules are numerous, interrelated, and change frequently. Applications where the Anemic Domain Model anti-pattern (objects with no behaviour) has caused business logic to bleed into service and controller layers.

**Benefits:** Business rules are co-located with the data they govern, making it impossible to violate a business invariant without going through the domain object. Rich domain models make the codebase a direct executable representation of the business, dramatically improving communication between developers and domain experts.

---

---

### Transaction Script

**Description:** A simple pattern where each business operation is implemented as a single procedural script that directly manipulates database records and contains all the logic for that transaction. It is straightforward but does not scale well to complex domains.

**Use Cases:** Simple CRUD applications, administrative screens, and utility scripts where the business logic is minimal and a full domain model would be over-engineering. Batch processing jobs that perform straightforward data transformation and persistence without complex rules.

**Benefits:** Extremely simple to implement, understand, and debug — the entire logic of an operation is in one place with no indirection. Fastest path to a working implementation for simple operations, with minimal architectural overhead.

---

---

### Table Module

**Description:** A single object that handles all business logic for all rows in a database table or view, using a DataSet or record set as its primary input. It is a middle ground between Transaction Script (no object structure) and Domain Model (per-instance objects).

**Use Cases:** Reporting and data processing applications that work with entire result sets rather than individual entity instances. Legacy .NET applications using DataSets where a full domain model migration is not feasible.

**Benefits:** Organises business logic by table rather than scattering it in scripts, providing a moderate improvement in organisation without the complexity of a full domain model. Works naturally with tabular data structures, reducing impedance mismatch.

---

---

### Active Record

**Description:** A pattern where a domain object wraps a database row and includes both the data access logic and the business logic within the same class. The object knows how to save, find, and delete itself from the database.

**Use Cases:** Simple applications and CRUD-heavy systems where the domain model closely mirrors the database schema and business rules are minimal. Ruby on Rails and Laravel applications where the framework convention uses Active Record as the default ORM pattern.

**Benefits:** Provides a convenient single object for data and persistence operations, reducing boilerplate for simple CRUD use cases. Simple to learn and use, making it well-suited to rapid application development and small teams.

---

---

### Service Layer

**Description:** An architectural pattern that defines an application's boundary and its set of available operations from the perspective of interfacing client layers. The service layer coordinates domain objects, orchestrates business transactions, and handles cross-cutting concerns such as security and transactions.

**Use Cases:** Application servers exposing business operations to multiple clients — web UIs, mobile apps, external APIs — that all need the same business transaction semantics without duplicating logic. Defining a clear boundary between the domain model and the presentation or integration layers.

**Benefits:** Provides a single, consistent place for all application-level orchestration, security, and transaction demarcation, keeping these concerns out of the domain model and UI layer. Makes the available use cases of the application explicit and discoverable through the service layer interface.

---

---

### Specification Pattern

**Description:** A behavioural pattern that encapsulates a business rule as a reusable, combinable object with a single method (isSatisfiedBy) that evaluates whether a given object meets the rule. Specifications can be combined using logical AND, OR, and NOT operations.

**Use Cases:** Complex eligibility or validation rules — such as loan eligibility criteria, identity verification risk scoring rules, or product catalogue filtering — that need to be combined dynamically at runtime. Replacing long if-else chains with composable, testable, named business rules.

**Benefits:** Makes complex business rules first-class, named objects that are independently testable and reusable across multiple contexts. Enables runtime composition of rules without modifying existing code, supporting the Open-Closed Principle.

---

---

### Factory

**Description:** A creational pattern that provides a method or object for creating instances of a class or family of classes, hiding the construction logic and the specific concrete type from the caller. Factories centralise the knowledge of how to create complex objects.

**Use Cases:** Creating complex domain aggregates — such as a verification check with the correct tier, provider configuration, and initial state — where construction involves multiple steps and business rules. Creating different implementations of an interface based on a runtime parameter, such as selecting a identity verification provider based on customer nationality.

**Benefits:** Encapsulates construction complexity in a single place, making it easy to change how objects are created without modifying callers. Enforces that domain objects are always created in a valid initial state, preventing partially-constructed or inconsistent objects.

---

---

### Builder

**Description:** A creational pattern that separates the construction of a complex object from its representation, using a step-by-step fluent API to assemble the object incrementally before a final build() call returns the completed instance.

**Use Cases:** Constructing complex request or response objects in test code — such as building a complete onboarding application payload with optional fields set selectively. Creating complex configuration objects or domain aggregates that have many optional parameters.

**Benefits:** Produces highly readable object construction code via a fluent interface, making the intent of each parameter explicit. Prevents the telescoping constructor anti-pattern — dozens of constructor overloads — by using named method calls for each parameter.

---

---

### Singleton

**Description:** A creational pattern that ensures a class has only one instance and provides a global access point to it, typically used for shared stateless services, configuration objects, or resource managers that are expensive to create.

**Use Cases:** Application-wide shared services such as a configuration manager, connection pool, or logging service where a single instance must be shared. Thread pools and caches that must be initialised once and reused throughout the application lifecycle.

**Benefits:** Ensures only one instance of an expensive-to-create resource exists, preventing unnecessary resource duplication. Provides a globally accessible shared instance without requiring dependency injection in every calling class.

---

---

### Observer

**Description:** A behavioural pattern that defines a one-to-many dependency so that when one object changes state, all registered dependents (observers) are notified and updated automatically. Promotes loose coupling between the subject and its observers.

**Use Cases:** Event notification systems where multiple consumers need to react to a state change — such as multiple UI components updating when a customer profile changes. Domain event publishing within a bounded context where the aggregate publishes events that multiple domain services handle.

**Benefits:** Decouples the subject from its observers, allowing new consumers to be added without modifying the subject. Enables runtime addition and removal of observers, providing flexible and extensible event handling.

---

---

### Strategy

**Description:** A behavioural pattern that defines a family of algorithms, encapsulates each one, and makes them interchangeable at runtime. The strategy pattern allows the algorithm to vary independently from the clients that use it.

**Use Cases:** Selecting a identity verification verification provider (a third-party verification provider vs a sanctions screening provider) at runtime based on customer nationality or risk tier. Choosing between different pricing algorithms, discount strategies, or report formatting rules based on a runtime context parameter.

**Benefits:** Eliminates large conditional blocks (if-else / switch chains) for algorithm selection, replacing them with polymorphic strategy objects. New strategies can be added without modifying existing code, satisfying the Open-Closed Principle.

---

---

### Decorator

**Description:** A structural pattern that attaches additional responsibilities to an object dynamically by wrapping it in a decorator object that implements the same interface. Decorators provide a flexible alternative to subclassing for extending functionality.

**Use Cases:** Adding cross-cutting concerns such as logging, caching, retry logic, or metrics collection to a service implementation without modifying the service itself. Composing multiple behaviours onto a base object at runtime — such as a cached, logged, and rate-limited API client.

**Benefits:** Adds behaviour to objects without inheritance, avoiding the fragile base class problem. Allows behaviour composition to be determined at runtime, providing far more flexibility than static inheritance hierarchies.

---

---

### Facade

**Description:** A structural pattern that provides a simplified, unified interface to a complex subsystem, hiding the complexity of multiple components behind a single cohesive API. The facade does not encapsulate the subsystem but makes it easier to use.

**Use Cases:** Providing a simple unified view service facade that internally aggregates calls to the compliance verification service, a profile service, an account service, and a case service rather than exposing all four individually to an internal staff portal. Simplifying integration with complex third-party SDKs by wrapping them behind a domain-specific interface.

**Benefits:** Simplifies the interface seen by callers, reducing the learning curve and integration complexity. Decouples clients from the internal complexity of the subsystem, making it possible to refactor the subsystem without affecting callers.

---

---

### Adapter

**Description:** A structural pattern that converts the interface of a class into another interface that clients expect, allowing incompatible interfaces to work together. The adapter wraps the adaptee and translates method calls from the target interface to the adaptee's interface.

**Use Cases:** Integrating a third-party identity verification API (a third-party verification provider) whose response model differs from the internal identity verification domain model, using an adapter to translate the external response into internal domain types. Migrating from one database driver to another without modifying the application code by adapting the old interface to the new driver.

**Benefits:** Allows existing, incompatible classes to collaborate without modifying their source code. Isolates all interface translation logic in the adapter, making it easy to swap out the underlying implementation by replacing only the adapter.

---

---

### Proxy

**Description:** A structural pattern that provides a surrogate object that controls access to another object, adding a layer of indirection that can perform additional actions — such as lazy initialisation, access control, logging, or caching — before or after delegating to the real subject.

**Use Cases:** A caching proxy that intercepts calls to a profile service and returns cached results for recently accessed profiles without hitting the database. A security proxy that checks authorisation before delegating to the real service, centralising access control.

**Benefits:** Adds a control layer over object access without modifying the subject, supporting the Single Responsibility Principle. Enables capabilities like lazy loading, remote access abstraction, and access control transparently from the client's perspective.

---

---

### Chain of Responsibility

**Description:** A behavioural pattern that passes a request along a chain of handlers, where each handler decides to process the request or pass it to the next handler in the chain. The sender of the request has no knowledge of which handler will process it.

**Use Cases:** A identity verification decision pipeline where each handler in the chain applies a different check — document verification, sanctions screening, a high-risk entity flag check, risk scoring — and passes the request along after completing its step. Middleware pipelines in web frameworks where each middleware component either handles or forwards the HTTP request.

**Benefits:** Decouples the sender of a request from its receivers, allowing new handlers to be inserted or reordered without modifying existing code. Makes the processing pipeline explicit, composable, and individually testable per handler.

---

---

### Mediator

**Description:** A behavioural pattern that defines an object that encapsulates how a set of objects interact, promoting loose coupling by preventing objects from referring to each other explicitly. All communication is channelled through the mediator.

**Use Cases:** Complex UI components where multiple elements need to react to each other's changes — a form where changing one field updates options in several others — centralised through a form mediator. Implementing the CQRS command/query dispatcher pattern where commands and queries are dispatched through a central mediator that routes them to their handlers.

**Benefits:** Reduces the number of direct dependencies between interacting objects from a many-to-many mesh to a one-to-many hub-and-spoke, dramatically simplifying the interaction graph. Makes interaction logic centralised and inspectable in one place rather than distributed across all participants.

---

---

### State Machine

**Description:** A behavioural pattern that allows an object to alter its behaviour when its internal state changes, making the object appear to change its class. States are represented explicitly and transitions between them are governed by defined rules and events.

**Use Cases:** Modelling a customer onboarding application lifecycle — INITIATED → KYC_IN_PROGRESS → KYC_PASSED → ACCOUNT_OPENING → COMPLETED / REJECTED — where the valid actions depend entirely on the current state. a verification check lifecycle, loan application processing, order fulfilment workflows.

**Benefits:** Makes complex lifecycle logic explicit, readable, and provably correct by representing all states and transitions as a formal model. Eliminates the proliferation of boolean flags and if-else chains that attempt to track object lifecycle, replacing them with a clear, testable state graph.

---

---

### Saga Compensating Transaction

**Description:** A mechanism within the Saga pattern where each step in a distributed transaction has a corresponding compensating transaction that undoes the effect of that step, used when a subsequent step in the saga fails and the earlier steps must be rolled back to maintain business consistency.

**Use Cases:** A banking onboarding saga where step 7 (account opening) fails after steps 1–6 have succeeded — the compensating transactions for steps 1–6 must be executed to undo the prospect record creation, identity verification initiation, and document upload. Any multi-step distributed transaction where partial failure must result in a consistent final state.

**Benefits:** Provides a principled, auditable mechanism for distributed rollback without requiring distributed locking or two-phase commit. Each compensating transaction is independently testable and explicitly documented, making failure handling a first-class design concern.

---

---

### Read Model Projection

**Description:** A materialised, query-optimised view of application state built by processing a stream of domain events, providing a denormalised representation specifically tailored to the needs of a particular query or UI. Projections are rebuilt by replaying events from the event store.

**Use Cases:** Building a unified entity view read model that aggregates data from identity verification events, profile change events, account events, and case events into a single denormalised document optimised for an internal staff portal query. Generating reporting views that aggregate domain events into regulatory reports without impacting the transactional write side.

**Benefits:** Enables multiple independently optimised query models for different consumers without affecting the write model or forcing the write model to accommodate read concerns. Projections can be rebuilt or added at any time by replaying historical events, providing a powerful mechanism for evolving query capabilities.

---

---

### Aggregate Root

**Description:** A DDD tactical pattern that designates a single entity — the aggregate root — as the sole entry point to a cluster of related domain objects (the aggregate), enforcing all invariants across the cluster and controlling all access to child entities from outside the aggregate boundary.

**Use Cases:** Ensuring that a verification check can only be created and modified through the customer aggregate root, preventing direct manipulation of child identity verification records that might violate the customer's overall risk rating invariant. Defining transaction boundaries in microservices — one aggregate root typically maps to one transactional boundary per service.

**Benefits:** Enforces all aggregate-wide business invariants through a single entry point, preventing partial or inconsistent state changes that violate the business rules. Defines natural transaction boundaries, simplifying concurrency control to optimistic locking on the aggregate root.

---

---

### Value Object

**Description:** A DDD tactical pattern representing a domain concept defined entirely by its attributes with no conceptual identity — two value objects with the same attributes are considered equal. Value objects are immutable; changing an attribute creates a new value object rather than modifying the existing one.

**Use Cases:** Representing domain concepts such as Money (amount + currency), DateRange (start + end date), Address, NationalInsuranceNumber, or IBAN where equality is based on attribute values, not object identity. Replacing primitive obsession — raw strings and integers for domain concepts — with expressive, self-validating value objects.

**Benefits:** Immutability eliminates a large class of bugs caused by shared mutable state and unexpected modifications of passed-in objects. Self-validating value objects ensure that an invalid value — a negative Money amount, an incorrectly formatted IBAN — can never exist anywhere in the system.

---

---

### Domain Event

**Description:** A record of something significant that has happened in the domain, expressed in past tense (a DomainEntityCreated, a VerificationCompleted, an EntityActivated), that other parts of the system can subscribe to and react to. Domain events are immutable facts about what occurred.

**Use Cases:** Notifying the CRM system when a customer has been successfully onboarded, triggering a welcome email via the notification service, and updating an analytics platform — all from a single DomainEntityCreated domain event without the onboarding service knowing about any of these consumers. Decoupling side effects from the main business transaction.

**Benefits:** Decouples the producer of a business fact from all consumers, allowing new consumers to be added without modifying the producing service. Creates an auditable, immutable record of business facts that can be replayed for debugging, event sourcing, or building new projections.

---

---

### Two-Phase Commit (2PC)

**Description:** A distributed transaction protocol that coordinates atomic commits across multiple resource managers (databases, message brokers) in two phases: a prepare phase where all participants confirm readiness to commit, and a commit phase where the coordinator instructs all to commit or all to abort.

**Use Cases:** Legacy enterprise systems using XA transactions that must achieve atomicity across a relational database and a message queue. Scenarios where the Saga or Outbox pattern is not feasible due to technology constraints and true ACID guarantees across distributed resources are required.

**Benefits:** Guarantees strict atomicity across multiple resources — all commit or none commit — which eliminates the partial failure problem in distributed transactions. Provides familiar ACID semantics that developers understand from single-database transactions, reducing reasoning complexity.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
