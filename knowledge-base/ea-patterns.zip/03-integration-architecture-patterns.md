# Integration Architecture Patterns

> Patterns that define how disparate systems, services, and applications communicate and exchange data. These patterns address messaging, routing, transformation, reliability, and the topology of inter-system connections.

---

### Point-to-Point

**Description:** The simplest integration style where two systems communicate directly with each other via a dedicated, bilateral connection. Each integration is a bespoke link between a specific producer and a specific consumer.

**Use Cases:** Simple, low-volume integrations between two systems that will not grow — such as a nightly file transfer from a core banking system to a single downstream report. Early-stage integration where the cost of a broker is not justified.

**Benefits:** Extremely simple to implement and understand with no intermediary infrastructure required. Lowest possible latency as there is no broker hop between producer and consumer.

---

---

### Hub and Spoke

**Description:** An integration topology where all systems connect to a central hub (typically an ESB or integration platform) rather than to each other, with the hub routing, transforming, and mediating messages between spokes. Replaces n*(n-1) point-to-point connections with n connections to the hub.

**Use Cases:** Enterprise integration programmes connecting many heterogeneous systems — ERP, CRM, application backend, regulatory reporting — through a central integration platform such as an integration middleware or IBM Integration Bus. Organisations requiring centralised monitoring, transformation, and governance of all integration flows.

**Benefits:** Dramatically reduces the number of integration connections from quadratic to linear as the number of systems grows. Centralises transformation, routing, and monitoring logic, making it far easier to add new systems or change existing integrations.

---

---

### Enterprise Service Bus (ESB)

**Description:** A middleware infrastructure providing a shared communication backbone for connecting heterogeneous enterprise applications, offering services such as message routing, transformation, protocol mediation, orchestration, and guaranteed delivery. The ESB implements the Hub and Spoke topology.

**Use Cases:** Large enterprise integration programmes requiring centralised governance of all service-to-service communication, with standardised logging, security enforcement, and SLA monitoring across all integrations. Legacy system integration where multiple protocols (SOAP, JMS, FTP, JDBC) must be mediated into a common messaging model.

**Benefits:** Provides a single, governable integration platform that enforces consistent security, logging, and transformation policies across all integrations. Reduces duplication of cross-cutting integration concerns that would otherwise need to be implemented in every integrated system.

---

---

### Message Bus

**Description:** A shared communication channel that allows multiple systems to publish and consume messages without knowing about each other, using a common messaging infrastructure as the shared backbone. Unlike an ESB, a message bus typically does not perform transformation or orchestration.

**Use Cases:** Decoupling microservices in a cloud-native architecture using a managed message broker or Apache Kafka as the message bus, where services publish domain events and consume the events they care about. Building an event-driven platform where the message bus acts as the single source of truth for all inter-service communication.

**Benefits:** Decouples all producers and consumers spatially and temporally — services do not need to know about each other or be available simultaneously. The bus provides durability, ensuring messages survive broker restarts and consumer downtime.

---

---

### Event-Driven Architecture (EDA)

**Description:** An architectural paradigm where systems communicate by producing and consuming events — immutable records of things that have happened — rather than by direct request-response calls. Systems react to events asynchronously, enabling high decoupling and scalability.

**Use Cases:** Real-time banking platforms where a customer's identity verification status change must trigger reactions in onboarding, CRM, notification, and analytics services simultaneously without tight coupling. IoT platforms, financial trading systems, and fraud detection pipelines where high-throughput event processing is required.

**Benefits:** Achieves maximum decoupling between services — producers have no knowledge of consumers, and new consumers can be added without modifying the producer. Enables high scalability and resilience, as consumers process events independently and the system degrades gracefully when individual consumers are slow or unavailable.

---

---

### Publish-Subscribe (Pub/Sub)

**Description:** A messaging pattern where publishers send messages to a named topic without knowledge of subscribers, and subscribers receive all messages published to topics they are interested in. The broker decouples publishers from subscribers entirely.

**Use Cases:** Broadcasting a DomainEntityCreated event to multiple consumers — the CRM system, an analytics platform, a notification service, an audit service — without the onboarding service being aware of any of them. Distributing market data, price feeds, or regulatory alerts to multiple downstream consumers simultaneously.

**Benefits:** A single published event can fan out to any number of consumers with zero coupling between publisher and subscribers. New consumers can be added at any time by subscribing to an existing topic without any changes to the publisher or other consumers.

---

---

### Request-Reply

**Description:** A synchronous messaging pattern where a requester sends a message to a recipient and blocks (or uses a correlation ID) to wait for a corresponding reply message. It maps the familiar remote procedure call (RPC) model onto a messaging infrastructure.

**Use Cases:** Implementing synchronous API calls over asynchronous messaging infrastructure when a caller needs a result before continuing — such as a verification check that must return a decision before the onboarding saga can proceed. Enabling RPC-style interactions between microservices while retaining the durability and observability benefits of a message broker.

**Benefits:** Provides synchronous RPC semantics over asynchronous infrastructure, combining the reliability of message brokers with the simplicity of request-response programming. Correlation IDs enable tracking of matched request-reply pairs for debugging and monitoring.

---

---

### Fire and Forget

**Description:** An asynchronous messaging pattern where the sender publishes a message to a queue or topic and immediately continues processing without waiting for acknowledgement or a response. Delivery and processing are the responsibility of the messaging infrastructure and consumer.

**Use Cases:** Non-critical asynchronous operations such as sending a welcome notification after onboarding, publishing an audit log event, or triggering an analytics pipeline update — where the sender should not be blocked waiting for completion. Best-effort notifications where the business impact of occasional message loss is acceptable.

**Benefits:** Eliminates all blocking waiting time on the sender side, maximising throughput and responsiveness of the producing service. Decouples the sender from the receiver's availability — the sender succeeds even if the consumer is temporarily down.

---

---

### Content-Based Router

**Description:** A messaging integration pattern that inspects the content (fields, type, or payload) of a message and routes it to one of multiple output channels based on routing rules derived from the message content. The router makes no changes to the message itself.

**Use Cases:** Routing a verification check requests to the correct third-party provider (a third-party verification provider for UK nationals, a sanctions screening provider for international customers) based on the nationality field in the message. Routing incoming messages to different processing queues based on message type or priority flag in the header.

**Benefits:** Centralises routing logic in a single, testable component rather than scattering conditional logic across all consumers. Makes routing rules explicit and independently maintainable without modifying the producers or consumers of the messages.

---

---

### Message Filter

**Description:** An integration pattern that passes only messages matching specific criteria through to the output channel, silently discarding messages that do not match the filter predicate. It acts as a selective gateway in a message processing pipeline.

**Use Cases:** Filtering an incoming stream of customer events to only forward HIGH-risk customer events to the fraud team's queue, discarding LOW and MEDIUM risk events. Preventing test or synthetic events generated in production from reaching downstream analytics or regulatory reporting systems.

**Benefits:** Reduces the volume of messages that downstream consumers must process, improving their throughput and reducing noise. Keeps consumer logic simple by ensuring each consumer only receives exactly the messages it needs to process.

---

---

### Message Aggregator

**Description:** An integration pattern that collects and combines multiple related messages into a single, consolidated message before forwarding it to the next processing step. The aggregator uses a correlation ID to group related messages and a completion condition to determine when to release the aggregate.

**Use Cases:** Collecting all three a verification check results — document verification, sanctions screening, and risk scoring — from separate services and aggregating them into a single identity verification decision message before the onboarding saga can proceed. Assembling a complete order from multiple item-level messages published by different product services.

**Benefits:** Presents a unified, complete message to downstream processors that would otherwise need to correlate multiple partial messages themselves. Hides the parallel, multi-message nature of upstream processing from downstream consumers that expect a single, complete input.

---

---

### Splitter

**Description:** An integration pattern that receives a single message containing a list or batch of items and splits it into multiple individual messages — one per item — for parallel downstream processing. The splitter is the inverse of the aggregator.

**Use Cases:** Splitting a nightly batch file of 10,000 customer records into individual customer messages for parallel identity verification refresh processing by a pool of consumer instances. Breaking a bulk order message into individual product messages routed to separate fulfilment services.

**Benefits:** Enables parallel processing of batch items by routing individual messages to a pool of consumer instances, dramatically improving throughput. Simplifies individual consumer logic by ensuring each consumer receives a single, well-defined item rather than having to iterate over a batch.

---

---

### Scatter-Gather

**Description:** An integration pattern that broadcasts a request to multiple recipients in parallel (scatter), waits for responses from all or a subset of them, and aggregates the responses into a single reply (gather). Combines the Publish-Subscribe and Aggregator patterns.

**Use Cases:** Simultaneously requesting a credit risk score, a fraud probability score, and a sanctions check from three different providers in parallel and aggregating the three responses into a single identity verification decision. Requesting price quotes from multiple insurance providers in parallel and returning the best offer.

**Benefits:** Dramatically reduces total latency for multi-provider queries by parallelising all requests rather than making them sequentially. Provides a single consolidated result to the caller regardless of the number of underlying providers consulted.

---

---

### Process Manager

**Description:** An integration pattern that coordinates a multi-step business process spanning multiple message exchanges with multiple services, maintaining the state of the process and routing messages to the correct participants at each step. It is the stateful counterpart of a message router.

**Use Cases:** Orchestrating an onboarding saga across an onboarding service, a compliance verification service, a product service, a CRM system, and a notification service — tracking the current state of each customer's onboarding journey and routing messages to the correct next service. Long-running insurance claims processing or loan origination workflows.

**Benefits:** Centralises the orchestration logic and state of complex multi-party workflows in one place, making the business process explicit and auditable. Handles the complexity of correlating responses from multiple services without requiring individual services to track inter-service state.

---

---

### Routing Slip

**Description:** An integration pattern that attaches a list of processing steps (the routing slip) to a message at the start of a workflow, with each processing component performing its step and then forwarding the message to the next component on the slip. The routing logic is data-driven rather than hard-coded.

**Use Cases:** Document processing pipelines where the sequence of processing steps — OCR, classification, validation, enrichment, archival — varies depending on the document type specified in the routing slip. Flexible a verification check sequences where the checks performed depend on the customer's risk tier and nationality.

**Benefits:** Allows the processing sequence to be configured dynamically at runtime by modifying the routing slip rather than changing process orchestration code. Processing components are completely decoupled from each other and from the overall sequence, enabling easy reuse and reordering.

---

---

### Message Translator

**Description:** An integration pattern that converts a message from one format, protocol, or schema to another, enabling systems with incompatible data models to communicate through a shared integration layer. It is the integration-layer implementation of the Adapter pattern.

**Use Cases:** Translating a third-party verification provider identity verification API response (a third-party verification provider proprietary schema) into the internal the platform domain identity verification result schema before publishing to the internal message bus. Converting SWIFT financial messages into internal payment domain events for processing by the application backend.

**Benefits:** Isolates all schema translation logic in a dedicated, testable component rather than embedding it in producers or consumers. When either system's schema changes, only the translator needs to be updated, protecting all other components.

---

---

### Canonical Data Model

**Description:** An enterprise integration pattern that defines a single, standard data model shared across all integrated systems, to which each system maps its own proprietary model. All messages exchanged via the integration layer use the canonical model, eliminating the need for n-to-n translator pairs.

**Use Cases:** Defining a canonical Customer entity shared across CRM, application backend, a compliance verification service, and an analytics platform, with each system responsible for mapping to/from the canonical model. Enterprise data integration programmes where the number of integrated systems makes point-to-point translation mapping unmanageable.

**Benefits:** Reduces the number of translation mappings from O(n²) to O(n) as each system only needs to map to the canonical model, not to every other system's model. Provides a shared vocabulary for data exchange, reducing integration defects caused by semantic mismatches between system-specific data models.

---

---

### Envelope Wrapper

**Description:** An integration pattern that wraps a message payload in a standardised envelope that carries routing, metadata, security, and correlation information in addition to the business payload. The envelope is processed by the integration infrastructure while the payload is delivered to the application.

**Use Cases:** Adding correlation IDs, timestamp, source system, message type, and version information to all messages published to a managed message broker — implementing the CloudEvents v1.0 specification as an envelope standard. WS-Security SOAP headers providing authentication credentials in a standard envelope separate from the business payload.

**Benefits:** Standardises message metadata across all integration flows, enabling uniform correlation, tracing, routing, and security processing without requiring applications to embed infrastructure concerns in their payloads. The envelope provides a stable, versionable structure for metadata even as payloads evolve.

---

---

### Dead Letter Channel

**Description:** A special message channel to which messages that cannot be delivered or processed successfully are routed, allowing them to be inspected, reprocessed, or discarded without losing them. All undeliverable or failed-processing messages are preserved in the dead letter queue (DLQ).

**Use Cases:** Capturing onboarding event messages that fail schema validation or cannot be processed by the the CRM system consumer due to an unexpected payload format, for manual inspection and replay after fixing the consumer. Alerting operations teams when the dead letter queue depth exceeds a threshold, indicating a systematic processing failure.

**Benefits:** Prevents message loss from unprocessable messages — they are preserved in the DLQ rather than silently dropped. Provides an auditable record of all processing failures, enabling root cause analysis and selective message replay after the underlying issue is resolved.

---

---

### Guaranteed Delivery

**Description:** A messaging pattern that ensures a message will be delivered to its destination even in the presence of system failures, using a durable message store to persist messages until successful delivery is confirmed. The sender receives a delivery guarantee before the message reaches the consumer.

**Use Cases:** Financial transaction events — a DomainEntityCreated, an EntityActivated — that must not be lost even if the consuming service is temporarily unavailable or the message broker restarts. Any compliance-critical domain event where losing a message would constitute a regulatory gap.

**Benefits:** Eliminates message loss as a failure mode, providing at-least-once delivery semantics regardless of consumer or broker availability. Allows producers and consumers to operate independently with different availability characteristics without risking data loss at the integration layer.

---

---

### Idempotent Receiver

**Description:** A messaging pattern where the message consumer is designed to handle duplicate message delivery safely — producing the same result and side effects whether it processes a given message once or multiple times. Typically implemented by tracking processed message IDs.

**Use Cases:** A verification check consumers receiving a message from an at-least-once delivery queue must not trigger a duplicate a third-party verification API call or create a duplicate identity verification record if the same checkId is received twice. Banking transaction processors that must ensure a payment is credited exactly once regardless of how many times the event is delivered.

**Benefits:** Enables safe use of at-least-once delivery semantics from message brokers without risking duplicate business operations. Allows consumers to process messages without coordinating with the broker on exactly-once semantics, which is complex and expensive to achieve.

---

---

### Competing Consumers

**Description:** A messaging pattern where multiple consumer instances all subscribe to the same queue and compete to process each message, with the broker guaranteeing that each message is delivered to exactly one consumer. Enables horizontal scaling of message processing throughput.

**Use Cases:** Scaling a verification check processing by running 10 instances of the compliance verification service consumer all reading from the same a managed message broker queue, processing checks in parallel to meet peak demand. Any high-throughput message processing workload where a single consumer instance cannot keep up with the inbound message rate.

**Benefits:** Provides simple, linear horizontal scalability of message processing throughput by adding consumer instances without any coordination logic. Consumer instances are stateless and independently scalable, enabling elastic scaling up and down based on queue depth.

---

---

### Priority Queue

**Description:** A messaging pattern that routes high-priority messages to a dedicated queue that is processed before standard-priority queues, ensuring that time-sensitive messages receive preferential treatment regardless of overall queue volume. Implemented using separate physical queues per priority level.

**Use Cases:** Routing TIER_3_ESCALATED identity verification checks (a high-risk entity flag/Sanctions matches) to a high-priority compliance queue processed immediately by a dedicated analyst, while standard TIER_1 automated checks go to a normal-priority queue. Processing urgent regulatory reporting requests ahead of batch analytical queries.

**Benefits:** Ensures high-priority business operations are not starved by high volumes of lower-priority messages. Provides differentiated SLAs for different message classes without requiring separate deployment topologies.

---

---

### Claim Check

**Description:** A messaging pattern that stores large message payloads in a durable external store (e.g., object storage) and includes only a reference (claim check / pointer) in the message sent via the broker. The consumer retrieves the full payload from the external store using the claim check reference.

**Use Cases:** Identity verification document processing where a customer's uploaded identity document (potentially several MB) is stored in object storage, with only the document reference (blob URI) included in the identity verification processing event message on the Service Bus. Avoiding message broker size limits for large batch data payloads.

**Benefits:** Keeps message broker payloads small and fast, avoiding performance degradation and message size limit violations caused by large binary payloads. The external store can retain the large payload independently of the message broker's retention policy.

---

---

### Change Data Capture (CDC)

**Description:** An integration pattern that detects and captures changes (inserts, updates, deletes) made to a source database and streams those changes as events to downstream consumers in near real-time, without requiring changes to the source application code. Typically implemented via database transaction log reading.

**Use Cases:** Streaming changes to the Customer Profile database to an analytics platform in near real-time without polling, using Debezium to capture changes from the relational database transaction logs. Keeping a search index (Elasticsearch) synchronised with a source-of-truth relational database by consuming CDC events.

**Benefits:** Achieves near real-time data synchronisation between a source database and downstream consumers without adding any integration code to the source application. Captures all changes including those made by legacy applications or batch processes that cannot be modified to publish events.

---

---

### Lambda Architecture

**Description:** A big data processing architecture that handles both batch processing (batch layer) and real-time stream processing (speed layer) in parallel, merging their outputs in a serving layer to provide complete, accurate, and low-latency query results.

**Use Cases:** Regulatory reporting platforms that need both complete historical accuracy (batch layer processing all historical records) and near real-time alerts (speed layer processing live events) from the same data pipeline. Fraud detection systems combining historical pattern analysis with real-time transaction scoring.

**Benefits:** Provides both complete accuracy (from the batch layer processing the full dataset) and low latency (from the speed layer processing recent data) in a single architecture. The batch layer can reprocess historical data to correct errors without affecting the speed layer's real-time capabilities.

---

---

### Kappa Architecture

**Description:** A stream-first alternative to Lambda Architecture that eliminates the batch layer entirely, processing all data — both historical reprocessing and real-time — through a single streaming pipeline. Historical reprocessing is achieved by replaying the event log from the beginning.

**Use Cases:** Event-driven platforms where all data is captured as a stream of events in a durable log (Kafka / cloud Event Hubs) and all processing — historical analysis and real-time — can be expressed as stream transformations. Simplifying Lambda Architecture deployments where maintaining dual batch and streaming codebases is too costly.

**Benefits:** Significantly reduces operational complexity by maintaining a single processing codebase for both real-time and historical processing, eliminating the dual-maintenance burden of Lambda Architecture. Historical reprocessing is simply a matter of replaying the event log, using the same pipeline logic.

---

---

### Webhook

**Description:** An HTTP callback pattern where a system registers a URL endpoint with an external service, and the external service sends HTTP POST requests to that endpoint whenever a specified event occurs. Webhooks replace polling by pushing event notifications to the registered URL.

**Use Cases:** Receiving real-time notifications from the CRM platform when a CRM record is updated, triggered as a the CRM platform outbound message webhook to the application backend. Payment gateway notifications for transaction status updates (settled, declined, refunded) pushed to the banking platform.

**Benefits:** Eliminates continuous polling overhead, reducing latency from hours (batch polling) or minutes (frequent polling) to seconds for event notification. Decouples the event source from the consumer — the source only needs to know the webhook URL, not anything about the consumer's internal architecture.

---

---

### Long Polling

**Description:** An HTTP technique where a client sends a request to the server that the server holds open until either new data is available or a timeout expires, then immediately returns the response. The client then immediately sends a new request, maintaining a near-continuous connection.

**Use Cases:** Real-time status polling for a verification check result where the client needs to know the outcome as soon as it is available but WebSockets are not available. Legacy systems that need near real-time updates but cannot implement a persistent connection.

**Benefits:** Achieves near real-time push semantics over standard HTTP without the complexity of WebSocket connections or server-side event infrastructure. Compatible with all HTTP infrastructure including load balancers and firewalls that may block persistent connections.

---

---

### Server-Sent Events (SSE)

**Description:** A web standard that allows a server to push a stream of events to a browser or HTTP client over a single, persistent HTTP connection using a simple text-based protocol. The connection is unidirectional — server to client — and automatically reconnects if dropped.

**Use Cases:** Streaming real-time onboarding status updates (identity verification processing, account opening, completion) to the customer-facing portal as a live activity feed without the bidirectional overhead of WebSockets. Pushing live compliance dashboard metric updates to a BI reporting tool Embedded widget.

**Benefits:** Provides server-to-client real-time streaming over standard HTTP with built-in reconnection, no additional protocol complexity, and native browser support. Simpler to implement and proxy-compatible compared to WebSockets for purely unidirectional streaming use cases.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
