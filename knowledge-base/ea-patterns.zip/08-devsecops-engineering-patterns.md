# DevSecOps & Engineering Patterns

> Patterns that embed security, quality, and operational excellence into the software delivery lifecycle. These patterns cover CI/CD pipeline design, testing strategies, observability, metrics, and the cultural practices that underpin high-performing engineering teams.

---

### CI/CD Pipeline

**Description:** A continuous integration and continuous delivery pipeline that automatically builds, tests, security-scans, and deploys application code changes as soon as they are committed, providing rapid, reliable feedback and delivery cycles. Every commit triggers the full pipeline from build to deployment.

**Use Cases:** The platform a CI/CD platform pipeline that builds all 8 microservices, runs unit tests, SAST, dependency scanning, container scanning, integration tests, and deploys to SIT on every merge to main — providing sub-30-minute feedback on every change. Automating all quality gates, removing manual testing bottlenecks.

**Benefits:** Eliminates the risk accumulation of infrequent, large releases by delivering small, well-tested changes continuously. Automated quality gates catch defects, security issues, and regressions immediately when they are cheapest to fix — at the point of code change.

---

---

### Trunk-Based Development

**Description:** A source control practice where all developers commit directly to a single main branch (trunk) or use very short-lived feature branches (< 3 days), avoiding long-lived divergent branches. The trunk is always in a releasable state; incomplete features are hidden behind feature flags.

**Use Cases:** The platform engineering team committing all changes to main with features hidden behind cloud App Configuration feature flags, enabling deployments to production multiple times per day without feature-branch integration issues. Eliminating the "merge hell" of long-lived feature branches that diverge significantly from the main codebase.

**Benefits:** Eliminates integration risk by ensuring all code changes are continuously integrated with each other, catching integration conflicts immediately when they are trivial to resolve rather than at the end of a sprint. Enables continuous deployment by keeping the main branch always in a deployable state.

---

---

### Shift-Left Security

**Description:** A DevSecOps practice that moves security testing and validation as early as possible in the development lifecycle — into the developer's IDE, pre-commit hooks, and CI pipeline — rather than performing security reviews only at the end of the development cycle.

**Use Cases:** The platform developers running a SAST tool SAST analysis in their IDE before committing, with a secrets scanning tool pre-commit hooks blocking secret commits, and a dependency scanning tool blocking merges with HIGH CVEs — catching security issues before they reach a review queue. Running OWASP dependency checks and container scans in every PR build, not just in pre-release security reviews.

**Benefits:** Dramatically reduces the cost of fixing security issues by finding them at the point of code creation rather than weeks later during a security review or, worse, after deployment to production. Creates a security-aware engineering culture where developers receive immediate, actionable security feedback as part of their normal workflow.

---

---

### Observability (Logs / Metrics / Traces)

**Description:** A property of a system that allows its internal state to be inferred from external outputs — logs (discrete events), metrics (numeric time-series measurements), and distributed traces (causally connected spans across service calls). A highly observable system can be debugged and understood without modifying it.

**Use Cases:** The platform emitting structured JSON logs to a centralised monitoring service, publishing custom metrics (onboarding completion rate, identity verification decision latency) to an application performance monitoring service, and emitting an observability standard distributed traces that track a customer's onboarding request across all 6 microservices it touches. Enabling on-call engineers to diagnose production incidents without adding debug logging to running services.

**Benefits:** Enables fast, accurate diagnosis of production incidents by providing correlated logs, metrics, and traces that together answer "what happened, where, and why." Provides proactive visibility into system behaviour before incidents occur, enabling anomaly detection and capacity planning based on real-time data.

---

---

### Four Golden Signals

**Description:** A Google SRE monitoring framework that defines the four most important signals to monitor for any service: Latency (time to service a request), Traffic (demand on the system), Errors (rate of failing requests), and Saturation (how full the service's resources are).

**Use Cases:** The application backend dashboards showing the four golden signals for each microservice in a centralised monitoring service — P95 API latency, requests per second, 5xx error rate percentage, and the container platform CPU/memory saturation — as the primary on-call operational view. Defining SLO alert thresholds based on each of the four signals.

**Benefits:** Provides a concise, universally applicable monitoring framework that captures the most actionable indicators of service health in four metrics, avoiding alert fatigue from monitoring dozens of less meaningful signals. Enables consistent, comparable monitoring across all microservices using the same framework.

---

---

### SLO / SLI / Error Budget

**Description:** A Google SRE framework where Service Level Objectives (SLOs) define the target reliability level for a service, Service Level Indicators (SLIs) are the metrics that measure actual reliability, and Error Budgets quantify the allowed unreliability per time window — the acceptable deviation from 100% reliability.

**Use Cases:** The application backend SLO: 99.9% of identity verification API requests served within 30 seconds over a 30-day window; the SLI is measured by an application performance monitoring service; the monthly error budget is 43.8 minutes of requests exceeding 30 seconds. When the error budget is exhausted, new feature deployments are paused until reliability recovers.

**Benefits:** Creates a data-driven, objective conversation between engineering and business about reliability — the error budget quantifies how much unreliability is acceptable, enabling rational trade-off decisions between reliability investment and feature velocity. Aligns incentives by making reliability degradation consequential (feature freeze) without requiring perfection.

---

---

### DORA Metrics

**Description:** Four metrics developed by the DevOps Research and Assessment (DORA) team — Deployment Frequency, Lead Time for Changes, Change Failure Rate, and Mean Time to Recovery (MTTR) — that have been empirically proven to predict software delivery performance and organisational outcomes.

**Use Cases:** The platform engineering team tracking DORA metrics in a CI/CD platform dashboards: targeting deployment frequency of 2+ per week per microservice, lead time < 2 days, change failure rate < 5%, and MTTR < 1 hour — using these as the primary indicators of engineering team health and delivery effectiveness. Using DORA metric trends to identify which service's pipeline has the highest change failure rate and focusing improvement effort there.

**Benefits:** Provides four empirically validated metrics that reliably distinguish high-performing engineering teams from low-performing ones, enabling data-driven engineering improvement programmes. Short feedback loops created by improving DORA metrics correlate strongly with better business outcomes — faster feature delivery with lower production incident rates.

---

---

> **Document Information**
> - **Format:** Pattern Name → Description → Use Cases → Benefits
> - **Audience:** Enterprise Architects, Solution Architects, Engineering Teams
> - **Version:** 1.0 | April 2026
